import atexit
import asyncio
import json
import os
import signal
import subprocess
import sys
from pathlib import Path
from textwrap import dedent
from typing import Any, Dict, List, Optional

import click
from rich.console import Console
from rich.markup import escape
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Confirm, Prompt
from rich.syntax import Syntax
from rich.table import Table

from .result_streamer import extract_score_from_grade_result

console = Console()

APEX_ASCII_ART = """
    █████╗ ██████╗ ███████╗██╗  ██╗    █████╗ ██████╗ ███████╗███╗   ██╗ █████╗ 
   ██╔══██╗██╔══██╗██╔════╝╚██╗██╔╝   ██╔══██╗██╔══██╗██╔════╝████╗  ██║██╔══██╗
   ███████║██████╔╝█████╗   ╚███╔╝    ███████║██████╔╝█████╗  ██╔██╗ ██║███████║
   ██╔══██║██╔═══╝ ██╔══╝   ██╔██╗    ██╔══██║██╔══██╗██╔══╝  ██║╚██╗██║██╔══██║
   ██║  ██║██║     ███████╗██╔╝ ██╗   ██║  ██║██║  ██║███████╗██║ ╚████║██║  ██║
   ╚═╝  ╚═╝╚═╝     ╚══════╝╚═╝  ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝╚═╝  ╚═╝
"""

WELCOME_MESSAGE = """
Welcome to Apex Arena! 🚀

Apex Arena is a platform for testing and evaluating your challenging problems with the "Bigfoot".
Here's what you can do:

1. [bold cyan]Setup[/bold cyan] - Configure your environment and start the MCP server
2. [bold green]Grade[/bold green] - Test and grade specific problem
3. [bold yellow]Eval[/bold yellow] - Run evaluations across multiple tasks and aggregate results

Choose an option to get started!
"""

# Global tracking for containers that need cleanup on exit
_active_containers: List[str] = []


def cleanup_stale_iptables_rules(silent: bool = False) -> int:
    """Clean up stale iptables rules from previous apex_arena runs.

    This finds and removes any rules in the DOCKER-USER chain that reference
    container IPs that no longer exist.

    SAFETY: This function is conservative - it only removes rules for IPs that
    we can definitively confirm have no running container. If we can't verify
    the state of running containers, we skip cleanup entirely.

    Returns the number of rules removed.
    """
    import re

    # Get list of currently running container IPs
    result = subprocess.run(
        ["docker", "ps", "-q"],
        capture_output=True,
        text=True,
    )

    # CRITICAL: If docker ps fails, do NOT proceed - we can't safely determine
    # which containers are running, so we might remove rules for active containers
    if result.returncode != 0:
        if not silent:
            console.print("[yellow]Could not list running containers, skipping iptables cleanup[/yellow]")
        return 0

    running_containers = result.stdout.strip().split('\n') if result.stdout.strip() else []

    active_ips = set()
    inspect_failures = 0
    for container_id in running_containers:
        if not container_id:
            continue
        result = subprocess.run(
            ["docker", "inspect", container_id, "--format",
             "{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}"],
            capture_output=True,
            text=True,
        )
        # CRITICAL: If we fail to get a container's IP, we must be conservative
        # and skip cleanup to avoid removing rules for running containers
        if result.returncode != 0:
            inspect_failures += 1
            continue
        ip = result.stdout.strip()
        if ip:
            active_ips.add(ip)

    # If we failed to inspect any containers, skip cleanup to be safe
    if inspect_failures > 0:
        if not silent:
            console.print(f"[yellow]Could not inspect {inspect_failures} container(s), skipping iptables cleanup[/yellow]")
        return 0

    # Get current DOCKER-USER rules
    check_script = """
apk add iptables >/dev/null 2>&1
iptables -L DOCKER-USER -n --line-numbers 2>/dev/null | grep -E '^[0-9]+' | while read line; do
    echo "$line"
done
"""
    try:
        result = subprocess.run(
            ["docker", "run", "--rm", "--privileged", "--net=host", "alpine", "sh", "-c", check_script],
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.TimeoutExpired:
        if not silent:
            console.print("[yellow]Timeout checking iptables rules[/yellow]")
        return 0

    if result.returncode != 0:
        if not silent:
            console.print("[yellow]Could not check iptables rules[/yellow]")
        return 0

    # Parse rules and find orphaned IPs
    # Match Docker bridge network IPs (172.17.x.x to 172.31.x.x covers typical Docker ranges)
    orphaned_ips = set()
    for line in result.stdout.strip().split('\n'):
        if not line:
            continue
        # Look for Docker bridge IPs (172.17-31.x.x pattern)
        ip_match = re.search(r'172\.(1[7-9]|2[0-9]|3[01])\.\d+\.\d+', line)
        if ip_match:
            ip = ip_match.group()
            if ip not in active_ips:
                orphaned_ips.add(ip)

    if not orphaned_ips:
        if not silent:
            console.print("[green]No stale iptables rules found[/green]")
        return 0

    # Remove rules for orphaned IPs
    rules_removed = 0
    for orphaned_ip in orphaned_ips:
        if not silent:
            console.print(f"[yellow]Removing stale iptables rules for {orphaned_ip}...[/yellow]")
        cleanup_script = f"""
apk add iptables >/dev/null 2>&1
count=0
while iptables -L DOCKER-USER -n --line-numbers | grep -q {orphaned_ip}; do
    line=$(iptables -L DOCKER-USER -n --line-numbers | grep {orphaned_ip} | head -1 | awk '{{print $1}}')
    iptables -D DOCKER-USER $line
    count=$((count + 1))
done
echo $count
"""
        try:
            result = subprocess.run(
                ["docker", "run", "--rm", "--privileged", "--net=host", "alpine", "sh", "-c", cleanup_script],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0 and result.stdout.strip().isdigit():
                rules_removed += int(result.stdout.strip())
        except subprocess.TimeoutExpired:
            if not silent:
                console.print(f"[yellow]Timeout removing rules for {orphaned_ip}[/yellow]")

    if not silent:
        console.print(f"[green]Removed {rules_removed} stale iptables rules[/green]")
    return rules_removed


def _cleanup_on_exit(container_name: str):
    """Cleanup handler for a specific container."""
    def handler(signum=None, frame=None):
        console.print(f"\n[yellow]Cleaning up container {container_name}...[/yellow]")
        cleanup_container(container_name)
        if signum is not None:
            sys.exit(1)
    return handler


def register_container_cleanup(container_name: str):
    """Register cleanup handlers for a container.

    This ensures iptables rules are cleaned up even if the process is killed.
    """
    global _active_containers
    _active_containers.append(container_name)

    handler = _cleanup_on_exit(container_name)

    # Register signal handlers
    signal.signal(signal.SIGINT, handler)
    signal.signal(signal.SIGTERM, handler)

    # Register atexit handler as backup
    atexit.register(handler)


def unregister_container_cleanup(container_name: str):
    """Unregister cleanup handlers after successful cleanup."""
    global _active_containers
    if container_name in _active_containers:
        _active_containers.remove(container_name)

    # Reset signal handlers to default
    if not _active_containers:
        signal.signal(signal.SIGINT, signal.SIG_DFL)
        signal.signal(signal.SIGTERM, signal.SIG_DFL)


def _print_entrypoint_logs(entrypoint_log_file: Path, title: str = "Docker Entrypoint Logs", max_lines: int = 0) -> None:
    """Print the Docker entrypoint logs with nice formatting.

    Args:
        entrypoint_log_file: Path to the entrypoint log file
        title: Title to display above the logs
        max_lines: Maximum number of lines to display (0 = all lines)
    """
    if not entrypoint_log_file or not entrypoint_log_file.exists():
        console.print(f"[yellow]No entrypoint logs available at {entrypoint_log_file}[/yellow]")
        return

    try:
        with open(entrypoint_log_file, "r") as f:
            lines = f.readlines()

        if not lines:
            console.print(f"[dim]Entrypoint log file is empty: {entrypoint_log_file}[/dim]")
            return

        console.print(f"\n[bold cyan]{'=' * 60}[/bold cyan]")
        console.print(f"[bold cyan]{title}[/bold cyan]")
        console.print(f"[dim]Log file: {entrypoint_log_file}[/dim]")
        console.print(f"[bold cyan]{'=' * 60}[/bold cyan]")

        # Limit lines if specified
        if max_lines > 0 and len(lines) > max_lines:
            console.print(f"[dim](Showing last {max_lines} of {len(lines)} lines)[/dim]")
            lines = lines[-max_lines:]

        for line in lines:
            # Strip trailing newline and escape rich markup
            line = line.rstrip('\n')
            console.print(f"[dim]{escape(line)}[/dim]")

        console.print(f"[bold cyan]{'=' * 60}[/bold cyan]\n")

    except Exception as e:
        console.print(f"[yellow]Failed to read entrypoint logs: {e}[/yellow]")


def configure_inotify():
    """Configure inotify settings for better file watching support.

    Runs sysctl commands to increase inotify limits. Shows warning if failed,
    info message if successful.
    """
    sysctl_commands = [
        ("fs.inotify.max_user_watches", "524288"),
        ("fs.inotify.max_user_instances", "1024"),
    ]

    all_success = True
    for param, value in sysctl_commands:
        try:
            result = subprocess.run(
                ["sysctl", "-w", f"{param}={value}"],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                all_success = False
        except Exception:
            all_success = False

    if all_success:
        console.print("[dim]inotify limits configured (max_user_watches=524288, max_user_instances=1024)[/dim]")
    else:
        console.print("[yellow]Warning: Failed to configure inotify limits. You may need to run with sudo or configure manually:[/yellow]")
        console.print("[yellow]  sysctl -w fs.inotify.max_user_watches=524288[/yellow]")
        console.print("[yellow]  sysctl -w fs.inotify.max_user_instances=1024[/yellow]")


def format_option(func):
    """Shared --format option for CLI commands.

    Adds a --format flag to specify the task format:
    - auto: Auto-detect format from task directory (default)
    - apex: Original Apex Arena format (task.yaml + grader.py)
    - harbor: Harbor framework format (task.toml + instruction.md)
    """
    return click.option(
        "--format",
        "task_format",
        type=click.Choice(["auto", "apex", "harbor"], case_sensitive=False),
        default="auto",
        help="Task format: auto (default), apex, or harbor",
    )(func)


def validate_agent_for_format(agent: str | None, task_format: str) -> str | None:
    """Validate and resolve agent for the given format.

    Args:
        agent: Agent identifier or None for default
        task_format: Task format ("apex" or "harbor")

    Returns:
        Validated agent identifier or None if using default

    Raises:
        click.BadParameter: If agent is not valid for the format
    """
    from .task_formats import FormatRegistry

    adapter = FormatRegistry.get_adapter(task_format)
    supported = adapter.get_supported_agents()
    default = adapter.get_default_agent()

    if agent is None:
        return None  # Will use default agent

    if not adapter.is_valid_agent(agent):
        raise click.BadParameter(
            f"Agent '{agent}' is not valid for {task_format} format. "
            f"Supported agents: {', '.join(supported)}. Default: {default}"
        )

    return agent


def get_agent_help_text(task_format: str = "apex") -> str:
    """Get help text for agent option based on format."""
    from .task_formats import FormatRegistry

    adapter = FormatRegistry.get_adapter(task_format)
    supported = adapter.get_supported_agents()
    default = adapter.get_default_agent()
    return f"Agent type. Supported for {task_format}: {', '.join(supported)}. Default: {default}"


def check_docker_image_exists(image_name: str) -> bool:
    """Check if a Docker image exists."""
    result = subprocess.run(
        ["docker", "images", "-q", image_name], capture_output=True, text=True
    )
    return bool(result.stdout.strip())


def check_docker_network_exists(network_name: str) -> bool:
    """Check if a Docker network exists."""
    result = subprocess.run(
        ["docker", "network", "ls", "-q", "-f", f"name={network_name}"],
        capture_output=True,
        text=True,
    )
    return bool(result.stdout.strip())


def create_restricted_network():
    """Create the restricted Docker network if it doesn't exist."""
    network_name = "restricted_net"

    if check_docker_network_exists(network_name):
        console.print(f"[green]Docker network '{network_name}' already exists[/green]")
        return

    console.print(f"[yellow]Creating Docker network '{network_name}'...[/yellow]")

    cmd = [
        "docker",
        "network",
        "create",
        "--driver",
        "bridge",
        "--internal",  # Block all external network access
        "--opt",
        "com.docker.network.bridge.enable_ip_masquerade=false",
        "--subnet",
        "172.31.0.0/16",
        network_name,
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        console.print(f"[red]Error creating Docker network: {result.stderr}[/red]")
        sys.exit(1)

    console.print(
        f"[green]Docker network '{network_name}' created successfully![/green]"
    )


def check_task_dockerfile(problem_id: str) -> bool:
    """Check if a task-specific Dockerfile exists."""
    dockerfile_path = Path.cwd() / "tasks" / problem_id / "Dockerfile"
    return dockerfile_path.exists()


def build_docker_image(
    problem_id: str | None = None, force_base: bool = False, force_task: bool = False
):
    """Build the Docker image for the given problem or base image if no problem specified.

    Args:
        problem_id: Task ID to build image for. If None, only builds base image.
        force_base: Force rebuild of base image (slow, rarely needed)
        force_task: Force rebuild of task-specific image (fast, useful after task updates)
    """
    # Get the package's installed path
    package_path = Path(__file__).parent

    # Always ensure base image exists first
    if force_base or not check_docker_image_exists("apex_arena:base"):
        console.print("[yellow]Building apex_arena:base Docker image...[/yellow]")
        result = subprocess.run(
            [
                "docker",
                "build",
                "--network=host",  # Use host network to avoid SSL issues on GCP VMs
                "-t",
                "apex_arena:base",
                "-f",
                package_path / "Dockerfile_cu",  # use the computer use dockerfile
                str(package_path),
            ],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            console.print(
                f"[red]Error building base Docker image: {result.stderr}[/red]"
            )
            sys.exit(1)
        console.print("[green]Base Docker image built successfully![/green]")

    # If no problem_id or no task-specific Dockerfile, return base image
    if not problem_id or not check_task_dockerfile(problem_id):
        return "apex_arena:base"

    # Check if task-specific image already exists
    image_name = f"apex_arena:{problem_id}"
    if not force_task and check_docker_image_exists(image_name):
        console.print(f"[green]Using existing task image {image_name}[/green]")
        return image_name

    # Build task-specific image if it doesn't exist or force_task is True
    task_dir = Path.cwd() / "tasks" / problem_id
    task_dockerfile = task_dir / "Dockerfile"
    console.print(
        f"[yellow]Building task-specific Docker image for {problem_id}...[/yellow]"
    )
    result = subprocess.run(
        [
            "docker",
            "build",
            "--network=host",  # Use host network to avoid SSL issues on GCP VMs
            "-t",
            image_name,
            "-f",
            str(task_dockerfile),
            ".",
        ],
        capture_output=True,
        text=True,
        cwd=task_dir,
    )
    if result.returncode != 0:
        console.print(f"[red]Error building task Docker image: {result.stderr}[/red]")
        sys.exit(1)
    console.print("[green]Specimen Docker image built successfully![/green]")
    return image_name


def run_mcp_server(problem_id: str | None = None, force: bool = False):
    """Run the MCP server."""
    console.print("[yellow]Starting MCP server...[/yellow]")

    # Clean up any stale iptables rules from previous runs
    cleanup_stale_iptables_rules(silent=True)

    # Build the appropriate Docker image
    image_name = build_docker_image(problem_id, force_base=force, force_task=force)

    # Generate container name based on problem_id or use default
    container_name = f"apex-arena-{problem_id}" if problem_id else "apex-arena-base"

    # Start on default bridge network first (required for port publishing)
    # We'll switch to restricted network after server is ready
    cmd = [
        "docker",
        "run",
        "-d",  # Run in detached mode
        "--name",
        container_name,
        "--privileged",  # Required for k3s
        "--cgroupns=host",  # Required for k3s cgroup management
        "-p",
        "8001:8001",
        "-v",
        "/sys/fs/cgroup:/sys/fs/cgroup:rw",  # Required for k3s
        "-v",
        f"{Path.cwd()}/tasks:/mcp_server/tasks",
        "-e",
        "MCP_TESTING_MODE=1",
        image_name,
        "python3",
        "/mcp_server/apex_arena/server.py",
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        console.print(f"[red]Error starting container: {result.stderr}[/red]")
        sys.exit(1)

    console.print(f"[green]Container {container_name} started[/green]")

    # Register cleanup handlers to ensure iptables rules are removed on exit
    register_container_cleanup(container_name)

    # Wait for server to be ready
    import time

    import httpx

    max_attempts = 1800  # Wait up to 30 minutes
    for attempt in range(max_attempts):
        try:
            response = httpx.get("http://localhost:8001/mcp", timeout=2)
            if response.status_code in [200, 404, 405, 406, 307]:
                console.print("[green]MCP server is ready[/green]")
                break
        except Exception:
            pass
        time.sleep(1)
        if attempt % 60 == 0:
            console.print(
                f"[dim]Waiting for server... ({attempt // 60}/{max_attempts // 60} minutes)[/dim]"
            )
    else:
        console.print("[red]Server failed to start in time[/red]")
        subprocess.run(["docker", "rm", "-f", container_name], capture_output=True)
        sys.exit(1)

    # Block internet access using iptables while keeping host communication working
    console.print("[yellow]🔒 Configuring network isolation...[/yellow]")

    # Get container IP and gateway IP
    result = subprocess.run(
        [
            "docker",
            "inspect",
            container_name,
            "--format",
            "{{range .NetworkSettings.Networks}}{{.IPAddress}},{{.Gateway}}{{end}}",
        ],
        capture_output=True,
        text=True,
    )
    ip_info = result.stdout.strip().split(",")
    if len(ip_info) == 2:
        container_ip = ip_info[0]
        gateway_ip = ip_info[1]

        # Use iptables to block internet while allowing host communication
        # Must insert at position 1 (before the default RETURN rule)
        # Insert in reverse order since -I adds to the top
        iptables_script = f"""
apk add iptables >/dev/null 2>&1
# Insert in reverse order (last rule first, first rule last)
# Drop everything else (public internet) - insert last
iptables -I DOCKER-USER 1 -s {container_ip} -j DROP
# Allow to private networks (RFC1918)
iptables -I DOCKER-USER 1 -s {container_ip} -d 192.168.0.0/16 -j ACCEPT
iptables -I DOCKER-USER 1 -s {container_ip} -d 172.16.0.0/12 -j ACCEPT
iptables -I DOCKER-USER 1 -s {container_ip} -d 10.0.0.0/8 -j ACCEPT
# Allow DNS
iptables -I DOCKER-USER 1 -s {container_ip} -p tcp --dport 53 -j ACCEPT
iptables -I DOCKER-USER 1 -s {container_ip} -p udp --dport 53 -j ACCEPT
# Allow all traffic to Docker gateway (host) - insert first
iptables -I DOCKER-USER 1 -s {container_ip} -d {gateway_ip} -j ACCEPT
"""

        result = subprocess.run(
            [
                "docker",
                "run",
                "--rm",
                "--privileged",
                "--net=host",
                "alpine",
                "sh",
                "-c",
                iptables_script,
            ],
            capture_output=True,
            text=True,
        )

        if result.returncode == 0:
            console.print(
                f"[green]✓ Network isolation enabled for {container_ip} - internet blocked, host access allowed[/green]"
            )
        else:
            console.print(
                f"[yellow]⚠ Failed to configure iptables: {result.stderr.strip()}[/yellow]"
            )
    else:
        console.print(
            "[yellow]⚠ Could not get container network info - internet not blocked[/yellow]"
        )

    # Create a Popen-like object to return for compatibility
    class ContainerProcess:
        def __init__(self, container_name):
            self.container_name = container_name
            self.returncode = None

        def wait(self):
            result = subprocess.run(
                ["docker", "wait", self.container_name], capture_output=True, text=True
            )
            return int(result.stdout.strip()) if result.stdout.strip() else 0

        def poll(self):
            result = subprocess.run(
                [
                    "docker",
                    "inspect",
                    self.container_name,
                    "--format",
                    "{{.State.Running}}",
                ],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0 or result.stdout.strip() == "false":
                return 0
            return None

        def terminate(self):
            subprocess.run(["docker", "stop", self.container_name], capture_output=True)

    process = ContainerProcess(container_name)

    console.print(
        f"[green]MCP server started successfully in container {container_name}![/green]"
    )
    console.print(f"[dim]View logs with: docker logs -f {container_name}[/dim]")

    return process


def cleanup_container(container_name: str):
    """Clean up the Docker container and associated iptables rules."""
    try:
        # Get container IP before removing it
        result = subprocess.run(
            [
                "docker",
                "inspect",
                container_name,
                "--format",
                "{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}",
            ],
            capture_output=True,
            text=True,
        )
        container_ip = result.stdout.strip()

        # Remove iptables rules for this container
        if container_ip:
            console.print(
                f"[yellow]Removing iptables rules for {container_ip}...[/yellow]"
            )
            # Remove all rules matching this container IP
            cleanup_script = f"""
apk add iptables >/dev/null 2>&1
# Keep deleting rules until none match (handles multiple rules)
while iptables -L DOCKER-USER -n --line-numbers | grep -q {container_ip}; do
    line=$(iptables -L DOCKER-USER -n --line-numbers | grep {container_ip} | head -1 | awk '{{print $1}}')
    iptables -D DOCKER-USER $line
done
"""
            subprocess.run(
                [
                    "docker",
                    "run",
                    "--rm",
                    "--privileged",
                    "--net=host",
                    "alpine",
                    "sh",
                    "-c",
                    cleanup_script,
                ],
                capture_output=True,
                text=True,
            )

        # Remove the container
        subprocess.run(
            ["docker", "rm", "-f", container_name], capture_output=True, text=True
        )
        console.print(f"[green]Cleaned up container {container_name}[/green]")

        # Unregister cleanup handlers
        unregister_container_cleanup(container_name)
    except Exception as e:
        console.print(
            f"[yellow]Warning: Could not clean up container {container_name}: {e}[/yellow]"
        )


def do_setup(
    problem_id: str | None = None, force: bool = False, task_format: str = "apex"
):
    """Perform the setup process.

    Args:
        problem_id: Optional problem ID to set up
        force: Force rebuild the Docker image
        task_format: Task format ("apex" or "harbor")
    """
    # Configure inotify limits for file watching
    configure_inotify()

    # For harbor format, setup is handled by harbor CLI
    if task_format == "harbor":
        console.print(
            "[yellow]Harbor format tasks use the harbor CLI for setup.[/yellow]"
        )
        console.print(
            "[blue]Run: harbor run -p <task_path> -a <agent> -m <model>[/blue]"
        )
        return

    # Generate container name based on problem_id or use default
    container_name = f"apex-arena-{problem_id}" if problem_id else "apex-arena-base"

    process = run_mcp_server(problem_id, force)

    try:
        console.print("[green]Setup complete! Press Ctrl+C to stop the server.[/green]")
        process.wait()
    except KeyboardInterrupt:
        console.print("\n[yellow]Shutting down MCP server...[/yellow]")
        process.terminate()
        process.wait()
    finally:
        cleanup_container(container_name)


def do_grade(
    problem_id: str, model: str, max_tokens: int = 8000, task_format: str = "apex"
):
    """Perform the grading process.

    Args:
        problem_id: Problem ID to grade
        model: Model to use for grading
        max_tokens: Maximum tokens for the model
        task_format: Task format ("apex" or "harbor")
    """
    # For harbor format, use harbor CLI
    if task_format == "harbor":
        from .task_resolver import get_tasks_dir

        tasks_dir = get_tasks_dir()
        task_dir = tasks_dir / problem_id

        console.print(
            f"[yellow]Running harbor grader for problem: {problem_id}[/yellow]"
        )

        cmd = [
            "harbor",
            "run",
            "-p",
            str(task_dir),
            "-m",
            model,
        ]

        try:
            result = subprocess.run(cmd, capture_output=False, text=True)
            if result.returncode == 0:
                console.print("[green]Harbor grading completed successfully![/green]")
            else:
                console.print(
                    f"[red]Harbor grading failed with exit code {result.returncode}[/red]"
                )
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
        return

    # Use the current Python executable instead of creating a separate venv
    # This ensures all dependencies are available
    python_path = sys.executable

    cmd = [
        str(python_path),
        "-m",
        "apex_arena.tester",
        "--problem_id",
        problem_id,
        "--model",
        model,
        "--max_tokens",
        str(max_tokens),
    ]

    console.print(f"[yellow]Running grader for problem: {problem_id}[/yellow]")

    # Run the process with live output
    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,  # Line buffered
        universal_newlines=True,
        env={
            **os.environ,
            "PYTHONUNBUFFERED": "1",
        },  # Ensure Python output is unbuffered
    )

    # Start threads to read and display output
    import threading

    def read_output(pipe, prefix):
        try:
            while True:
                line = pipe.readline()
                if not line and process.poll() is not None:
                    break
                if line:
                    console.print(f"{prefix} {line.strip()}")
                    console.file.flush()  # Force flush the output
        except Exception as e:
            console.print(f"[red]Error reading output: {escape(str(e))}[/red]")

    stdout_thread = threading.Thread(
        target=read_output, args=(process.stdout, "[green]Grader[/green]")
    )
    stderr_thread = threading.Thread(
        target=read_output, args=(process.stderr, "[red]Grader Error[/red]")
    )
    stdout_thread.daemon = True
    stderr_thread.daemon = True
    stdout_thread.start()
    stderr_thread.start()

    # Wait for the process to complete
    process.wait()

    # Wait for output threads to finish
    stdout_thread.join(timeout=1)
    stderr_thread.join(timeout=1)

    if process.returncode != 0:
        console.print("[red]Grading failed![/red]")
        sys.exit(1)

    console.print("[green]Grading completed![/green]")


async def do_tool_call(server_url: str, tool_name: str, tool_args: dict):
    """Perform a tool call on an existing MCP server."""
    try:
        from mcp import ClientSession
        from mcp.client.streamable_http import streamablehttp_client

        async with streamablehttp_client(server_url) as (
            read_stream,
            write_stream,
            _,
        ):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()

                # List available tools
                tools = await session.list_tools()
                available_tool_names = [tool.name for tool in tools.tools]

                if tool_name not in available_tool_names:
                    console.print(f"[red]Tool '{tool_name}' not found on server[/red]")
                    console.print(
                        f"[yellow]Available tools: {', '.join(available_tool_names)}[/yellow]"
                    )
                    return

                # Call the tool
                console.print(
                    f"[blue]Calling tool '{tool_name}' with args: {tool_args}[/blue]"
                )
                result = await session.call_tool(tool_name, tool_args)

                # Display result
                console.print("[green]Tool call successful![/green]")
                console.print("[bold]Result:[/bold]")

                for content in result.content:
                    if hasattr(content, "text"):
                        # Try to format as JSON if it looks like JSON
                        try:
                            parsed_json = json.loads(content.text)
                            syntax = Syntax(
                                json.dumps(parsed_json, indent=2),
                                "json",
                                theme="monokai",
                            )
                            console.print(syntax)
                        except (json.JSONDecodeError, TypeError):
                            # If not JSON, print as plain text
                            console.print(content.text)
                    else:
                        console.print(str(content))

                if result.isError:
                    console.print("[red]Tool call returned an error[/red]")

    except ImportError:
        console.print("[red]Error: Required MCP packages not available[/red]")
        console.print("[yellow]Make sure you have fastmcp installed[/yellow]")
    except Exception as e:
        console.print(f"[red]Error calling tool: {e}[/red]")


async def list_tools(server_url: str):
    """List all available tools on an MCP server."""
    try:
        from mcp import ClientSession
        from mcp.client.streamable_http import streamablehttp_client

        async with streamablehttp_client(server_url) as (
            read_stream,
            write_stream,
            _,
        ):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()

                # List available tools
                tools = await session.list_tools()

                if not tools.tools:
                    console.print("[yellow]No tools available on the server[/yellow]")
                    return

                # Create table to display tools
                table = Table(show_header=True, header_style="bold magenta")
                table.add_column("Tool Name", style="cyan")
                table.add_column("Description", style="white")
                table.add_column("Input Schema", style="dim")

                for tool in tools.tools:
                    # Format input schema
                    schema_str = ""
                    if hasattr(tool, "inputSchema") and tool.inputSchema:
                        if isinstance(tool.inputSchema, dict):
                            # Show properties if available
                            properties = tool.inputSchema.get("properties", {})
                            if properties:
                                schema_str = ", ".join(properties.keys())
                            else:
                                schema_str = str(tool.inputSchema.get("type", "object"))
                        else:
                            schema_str = str(tool.inputSchema)

                    table.add_row(
                        tool.name, tool.description or "No description", schema_str
                    )

                console.print(
                    f"\n[bold]Found {len(tools.tools)} tools on server:[/bold]"
                )
                console.print(table)

    except ImportError:
        console.print("[red]Error: Required MCP packages not available[/red]")
        console.print("[yellow]Make sure you have fastmcp installed[/yellow]")
    except Exception as e:
        console.print(f"[red]Error listing tools: {e}[/red]")


def interactive_task_selection(available_tasks: list) -> list:
    """Interactive checkbox selection of tasks."""

    # Start with all tasks selected by default
    selected = {task: False for task in available_tasks}

    while True:
        console.clear()
        console.print("[bold blue]Select tasks for Evaluation[/bold blue]\n")

        # Create a table showing tasks with checkboxes
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("#", style="dim", width=3)
        table.add_column("Status", width=8)
        table.add_column("Specimen", style="cyan")

        for i, task in enumerate(available_tasks, 1):
            status = "[green]✓[/green]" if selected[task] else "[red]✗[/red]"
            table.add_row(str(i), status, task)

        console.print(table)

        selected_count = sum(selected.values())
        console.print(f"\n[dim]Selected: {selected_count}/{len(available_tasks)}[/dim]")

        console.print("\n[bold]Commands:[/bold]")
        console.print("• Enter number(s) to toggle (e.g., '1,3,5' or '2-4')")
        console.print("• 'all' or 'a' - select all tasks")
        console.print("• 'none' or 'n' - deselect all tasks")
        console.print("• 'done' or 'd' - confirm selection")
        console.print("• 'quit' or 'q' - cancel evaluation")

        choice = Prompt.ask("\nCommand", default="done").strip().lower()

        if choice in ("done", "d"):
            break
        elif choice in ("quit", "q"):
            return []
        elif choice in ("all", "a"):
            for task in available_tasks:
                selected[task] = True
        elif choice in ("none", "n"):
            for task in available_tasks:
                selected[task] = False
        else:
            # Parse number selections
            try:
                indices = parse_selection_indices(choice, len(available_tasks))
                for idx in indices:
                    task = available_tasks[idx - 1]  # Convert to 0-based
                    selected[task] = not selected[task]
            except ValueError as e:
                console.print(f"[red]Invalid selection: {e}[/red]")
                console.input("\nPress Enter to continue...")

    return [task for task in available_tasks if selected[task]]


def parse_selection_indices(choice: str, max_count: int) -> list:
    """Parse selection like '1,3,5' or '2-4' into list of indices."""
    indices = []

    for part in choice.split(","):
        part = part.strip()
        if "-" in part:
            # Handle range like '2-4'
            start, end = part.split("-", 1)
            start_idx = int(start.strip())
            end_idx = int(end.strip())
            if start_idx < 1 or end_idx > max_count or start_idx > end_idx:
                raise ValueError(f"Invalid range: {part}")
            indices.extend(range(start_idx, end_idx + 1))
        else:
            # Handle single number
            idx = int(part)
            if idx < 1 or idx > max_count:
                raise ValueError(f"Number out of range: {idx}")
            indices.append(idx)

    return indices


def do_eval_interactive(force_build: bool = False):
    """Interactive evaluation setup."""
    import os

    # Discover available tasks
    tasks_dir = Path.cwd() / "tasks"
    from .eval_runner import EvalRunner

    runner = EvalRunner()
    available_tasks = runner.discover_tasks(tasks_dir)

    if not available_tasks:
        console.print("[red]No valid tasks found in tasks/ directory[/red]")
        return

    # Interactive task selection with checkboxes
    selected_tasks = interactive_task_selection(available_tasks)

    if not selected_tasks:
        console.print("[yellow]No tasks selected. Cancelling evaluation.[/yellow]")
        return

    # Get number of runs
    runs = int(Prompt.ask("Number of runs per task", default="3"))

    # Get other options
    model = Prompt.ask("Model to use", default="starburst")
    max_tokens = int(Prompt.ask("Max tokens", default="4096"))
    max_turns = int(Prompt.ask("Max conversation turns", default="800"))
    concurrency = int(Prompt.ask("Max concurrency", default="3"))
    debug_mode = Confirm.ask(
        "Enable debug mode (disables live progress bar)?", default=False
    )

    # Get streaming options (default to enabled)
    stream_results = Confirm.ask("Stream results to server?", default=True)
    apex_server_url = None
    apex_api_key = None

    if stream_results:
        apex_server_url = Prompt.ask(
            "Server URL",
            default=os.getenv(
                "APEX_SERVER_URL",
                "https://apex-ui-v2-319533213591.us-central1.run.app/",
            ),
        )
        apex_api_key = os.getenv("APEX_API_KEY")

        if not apex_api_key:
            console.print(
                "[red]Error: APEX_API_KEY environment variable must be set for streaming.[/red]"
            )
            console.print("[red]Please set APEX_API_KEY and try again.[/red]")
            return

    # Get output file
    output_file = Prompt.ask("Output JSON file", default="eval_results.json")

    # Confirm before running
    total_evals = len(selected_tasks) * runs
    console.print("\n[bold]Evaluation Summary:[/bold]")
    console.print(f"tasks: {', '.join(selected_tasks)}")
    console.print(f"Runs per task: {runs}")
    console.print(f"Total evaluations: {total_evals}")
    console.print(f"Max concurrency: {concurrency}")
    console.print(f"Output file: {output_file}")

    if not Confirm.ask("Proceed with evaluation?"):
        console.print("[yellow]Evaluation cancelled[/yellow]")
        return

    # Run the evaluation
    asyncio.run(
        do_eval(
            selected_tasks,
            runs,
            model,
            max_tokens,
            max_turns,
            concurrency,
            output_file,
            debug_mode,
            stream_results,
            apex_server_url,
            apex_api_key,
            force_build=force_build,
            task_versions=None,  # Interactive mode uses local tasks only
        )
    )


async def do_eval(
    tasks: list,
    runs: int,
    model: str,
    max_tokens: int,
    max_turns: int,
    concurrency: int,
    output_file: str,
    debug_mode: bool = False,
    stream_results: bool = False,
    apex_server_url: Optional[str] = None,
    apex_api_key: Optional[str] = None,
    force_build: bool = False,
    skip_validation: bool = False,
    task_versions: Optional[Dict[str, Any]] = None,
    evaluation_id: Optional[str] = None,
    cleanup_existing: bool = False,
    enable_computer_use: bool = False,
    agent_type: Optional[str] = None,
    updated_tasks: Optional[List[str]] = None,
    cpus: float = -1,
    no_cleanup: bool = False,
    task_format: str = "apex",
    run_index: Optional[int] = None,
):
    """Run the evaluation.

    Args:
        tasks: List of task IDs to evaluate
        runs: Number of runs per task
        model: Model to use for evaluation
        max_tokens: Maximum tokens per evaluation
        max_turns: Maximum conversation turns
        concurrency: Maximum concurrent evaluations
        output_file: Output JSON file path
        debug_mode: Enable debug mode
        stream_results: Enable streaming results to server
        apex_server_url: Apex UI server URL
        apex_api_key: Worker API key
        force_build: Force rebuild Docker images
        skip_validation: Skip validation checks
        task_versions: Task version information
        evaluation_id: Existing evaluation ID to add to
        cleanup_existing: Clean up existing containers
        enable_computer_use: Enable computer tool
        agent_type: Agent type to use
        updated_tasks: List of updated tasks (informational only - all images are always rebuilt)
        cpus: CPUs per container (-1 = all cores)
        no_cleanup: Keep containers after evaluation
        task_format: Task format ("apex" or "harbor")
        run_index: Run only a specific run (0-based index) for parallel execution
    """
    from .eval_runner import eval_runner_context

    try:
        async with eval_runner_context(
            model=model,
            max_tokens=max_tokens,
            max_turns=max_turns,
            max_concurrency=concurrency,
            debug_mode=debug_mode,
            stream_results=stream_results,
            apex_server_url=apex_server_url,
            apex_api_key=apex_api_key,
            skip_validation=skip_validation,
            task_versions=task_versions,
            evaluation_id=evaluation_id,
            cleanup_existing=cleanup_existing,
            enable_computer_use=enable_computer_use,
            agent_type=agent_type,
            updated_tasks=updated_tasks,
            cpus=cpus,
            no_cleanup=no_cleanup,
            task_format=task_format,
        ) as runner:
            results = await runner.run_evaluation(tasks, runs, force_build=force_build, run_index=run_index)

            # Write results to file
            with open(output_file, "w") as f:
                json.dump(results, f, indent=2)

            console.print(
                f"\n[green]Evaluation completed! Results saved to {output_file}[/green]"
            )

            # Print summary
            console.print("\n[bold]Summary:[/bold]")
            for task, agg in results["aggregated_results"].items():
                console.print(
                    f"[blue]{task}:[/blue] Mean score: {agg['mean_score']:.3f}, "
                    f"Variation: {agg['std_dev']:.3f}, CoV: {agg['coefficient_of_variation']:.3f}, "
                    f"Success rate: {agg['success_rate']:.1%}"
                )

            console.print("\n[dim]Transcripts saved to: eval_transcripts/[/dim]")

    except Exception as e:
        console.print(f"[red]Evaluation failed: {e}[/red]")
        raise


def interactive_menu():
    """Run the interactive menu."""
    console.print(Panel.fit(APEX_ASCII_ART, style="bold blue"))
    console.print(Panel(WELCOME_MESSAGE, style="bold white"))

    while True:
        choice = Prompt.ask(
            "What would you like to do?", choices=["1", "2", "3", "exit"], default="1"
        )

        if choice == "exit":
            console.print("[yellow]Goodbye! 👋[/yellow]")
            break
        elif choice == "1":
            problem_id = Prompt.ask(
                "Enter the problem ID (optional, press Enter to skip)", default=""
            )
            do_setup(problem_id if problem_id else None)
        elif choice == "2":
            problem_id = Prompt.ask("Enter the problem ID")
            model = Prompt.ask("Enter the model name", default="starburst")
            max_tokens = Prompt.ask("Enter the max tokens", default=8000)
            do_grade(problem_id, model, max_tokens)
        elif choice == "3":
            # TODO: Add force build option
            do_eval_interactive(force_build=False)


@click.group()
def cli():
    """Apex Arena CLI tool for testing and grading problems."""
    pass


def get_installed_version() -> str:
    """Get the currently installed apex_arena version."""
    try:
        from importlib.metadata import version

        return version("apex_arena")
    except Exception:
        return "unknown"


def compare_versions(current: str, latest: str) -> int:
    """Compare version strings. Returns: -1 if current < latest, 0 if equal, 1 if current > latest."""
    try:
        from packaging.version import Version

        current_v = Version(current)
        latest_v = Version(latest)
        if current_v < latest_v:
            return -1
        elif current_v > latest_v:
            return 1
        return 0
    except Exception:
        # Fallback to string comparison
        if current == latest:
            return 0
        return -1  # Assume update needed if we can't parse


def check_for_updates_silently():
    """Check for updates silently. Only prints if an update is available."""
    import requests

    try:
        server_url = os.getenv(
            "APEX_SERVER_URL", "https://proxy-319533213591.us-central1.run.app"
        ).rstrip("/")

        current_version = get_installed_version()
        if current_version == "unknown":
            return

        response = requests.get(f"{server_url}/cli/version", timeout=5)
        if response.status_code != 200:
            return

        version_info = response.json()
        latest_version = version_info.get("latest_version", "unknown")

        if latest_version == "unknown":
            return

        comparison = compare_versions(current_version, latest_version)

        if comparison < 0:  # Current version is older
            console.print(
                f"\n[yellow]⚠ Update available: {current_version} → {latest_version}[/yellow]"
            )
            console.print(
                "[dim]Run 'apex-arena update' to get the latest version[/dim]\n"
            )
    except Exception:
        # Silently ignore any errors during update check
        pass


@cli.command()
@click.option(
    "--force", is_flag=True, help="Force update even if already on latest version"
)
@click.option("--check", is_flag=True, help="Only check for updates, don't install")
def update(force: bool, check: bool):
    """Update apex-arena to the latest version."""
    import tempfile

    import requests

    # Get server URL
    server_url = os.getenv(
        "APEX_SERVER_URL", "https://proxy-319533213591.us-central1.run.app"
    ).rstrip("/")

    # Get current version
    current_version = get_installed_version()
    console.print(f"[blue]Current version:[/blue] {current_version}")

    # Check latest version from server
    console.print("[dim]Checking for updates...[/dim]")
    try:
        response = requests.get(f"{server_url}/cli/version", timeout=10)
        response.raise_for_status()
        version_info = response.json()
    except requests.RequestException as e:
        console.print(f"[red]Error checking for updates: {e}[/red]")
        sys.exit(1)

    latest_version = version_info.get("latest_version", "unknown")
    filename = version_info.get("filename", "apex_arena.whl")
    updated_at = version_info.get("updated_at", "unknown")

    console.print(f"[blue]Latest version:[/blue] {latest_version}")
    console.print(f"[dim]Last updated: {updated_at}[/dim]")

    # Compare versions
    comparison = compare_versions(current_version, latest_version)

    if comparison == 0 and not force:
        console.print("\n[green]✓ You are already on the latest version![/green]")
        return
    elif comparison == 1 and not force:
        console.print(
            "\n[yellow]⚠ Your version is newer than the server version (dev build?)[/yellow]"
        )
        return

    if check:
        console.print("\n[yellow]Update available![/yellow]")
        console.print(
            f"Run [cyan]apex-arena update[/cyan] to install version {latest_version}"
        )
        return

    # Download and install
    console.print(f"\n[yellow]Updating to version {latest_version}...[/yellow]")

    # Get API key for download
    api_key = os.getenv("APEX_API_KEY")
    if not api_key:
        console.print(
            "[red]Error: APEX_API_KEY environment variable is required for download.[/red]"
        )
        sys.exit(1)

    try:
        # Download wheel
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description="Downloading wheel...", total=None)

            response = requests.get(
                f"{server_url}/download_apex_wheel",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=120,
            )
            response.raise_for_status()

        # Save to temp directory with correct filename (pip validates wheel filenames)
        temp_dir = tempfile.mkdtemp()
        wheel_path = os.path.join(temp_dir, filename)
        with open(wheel_path, "wb") as f:
            f.write(response.content)

        console.print(f"[dim]Downloaded: {filename}[/dim]")

        # Install using pip
        console.print("[yellow]Installing...[/yellow]")
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", wheel_path],
            capture_output=True,
            text=True,
        )

        # Clean up temp directory
        try:
            os.unlink(wheel_path)
            os.rmdir(temp_dir)
        except Exception:
            pass

        if result.returncode != 0:
            console.print(f"[red]Installation failed: {result.stderr}[/red]")
            sys.exit(1)

        console.print(
            f"\n[green]✓ Successfully updated to version {latest_version}![/green]"
        )
        console.print(
            "[dim]Restart your terminal or run 'apex-arena --help' to use the new version.[/dim]"
        )

    except requests.RequestException as e:
        console.print(f"[red]Error downloading update: {e}[/red]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error installing update: {e}[/red]")
        sys.exit(1)


@cli.command()
def version():
    """Show the current apex-arena version."""
    current_version = get_installed_version()
    console.print(f"apex-arena version [bold cyan]{current_version}[/bold cyan]")
    console.print("[dim]Run 'apex-arena update --check' to check for updates[/dim]")


@cli.command(name="cleanup-iptables")
def cleanup_iptables_cmd():
    """Clean up stale iptables rules from previous apex_arena runs.

    This is useful if apex_arena was killed unexpectedly and left orphaned
    iptables rules that may be blocking network traffic.
    """
    console.print("[yellow]Checking for stale iptables rules...[/yellow]")
    rules_removed = cleanup_stale_iptables_rules(silent=False)
    if rules_removed > 0:
        console.print(f"[green]Cleanup complete! Removed {rules_removed} stale rules.[/green]")
    else:
        console.print("[green]No cleanup needed.[/green]")


@cli.command()
def start():
    """Start the Apex Arena interactive interface."""
    interactive_menu()


@cli.command()
@click.argument("task_name")
def init(task_name: str):
    """Initialize a new task template."""
    task_name = task_name.strip()
    if not task_name:
        raise click.BadParameter("Task name cannot be empty.", param="task_name")
    if Path(task_name).name != task_name or task_name in {".", ".."}:
        raise click.BadParameter(
            "Task name must not contain path separators.", param="task_name"
        )
    tasks_dir = Path.cwd() / "tasks"
    if not tasks_dir.exists():
        console.print(f"[yellow]No tasks directory found at {tasks_dir}.[/yellow]")
        if Confirm.ask(
            "[blue]Would you like to create it now?[/blue]",
            default=True,
        ):
            try:
                tasks_dir.mkdir(parents=True, exist_ok=True)
                console.print(f"[green]Created tasks directory at {tasks_dir}[/green]")
            except Exception as exc:
                raise click.ClickException(
                    f"Failed to create tasks directory: {exc}"
                ) from exc
        else:
            console.print("[red]Aborting task initialization.[/red]")
            return
    target_dir = tasks_dir / task_name
    try:
        target_dir.mkdir(parents=False, exist_ok=False)
    except FileExistsError:
        raise click.ClickException(f"Directory already exists: {target_dir}")
    file_templates = {
        "Dockerfile": dedent("""
        FROM apex_arena:base
        # -------------- Place holder for additional dependencies --------------
        RUN apt-get update && apt-get install -y --no-install-recommends python3-pip && apt-get clean
        # -------------- Place holder ends --------------
        # ------------ Place holder for operations --------------
        # Write your code here
        # ------------ Place holder for operations --------------
        # ------------ DONOT CHANGE --------------
        COPY ./tests/ /tests/
        COPY ./solution.sh /tests/
        COPY ./grader.py /tests/
        COPY ./data /workdir/data
        RUN chown -R model:model /workdir/data && chmod -R 700 /workdir/data
        """).strip(),
        "grader.py": dedent("""
        # Task-specific grader implementation.
        from apex_arena._types import GradingResult
        def grade(transcript):
            with open("/workdir/data/file.txt", "r") as f:
                content = f.read().strip()
            with open("/tests/gt.txt", "r") as f:
                gt = f.read().strip()
            if gt.strip() == content.strip():
                return GradingResult(score=1.0, subscores={"file_check": 1.0}, weights={"file_check": 1.0}, feedback="File content is correct.")
            return GradingResult(score=0.0, subscores={"file_check": 0.0}, weights={"file_check": 1.0}, feedback="File content is incorrect.")
        """).strip(),
        "task.yaml": dedent("""
        prompt:
        metadata:
            category: "Example Category"
            difficulty: "Easy"
            tags:
                - "example"
            memory_limit: 1024
            time_limit: 60
        """).strip(),
        "solution.sh": "#!/bin/bash\n\n# TODO: implement reference solution\n",
        "data/.empty": "Empty placeholder file - please delete this file if you add any files to this folder",
        "tests/.empty": "Empty placeholder file - please delete this file if you add any files to this folder",
    }
    for filename, content in file_templates.items():
        path = target_dir / filename
        if filename.endswith(".empty"):
            os.makedirs(path.parent, exist_ok=True)
            path.touch()
        path.write_text(content)
        if filename == "solution.sh":
            path.chmod(0o755)
    console.print(
        f"[green]✓ Created new task template at {target_dir}[/green]\n"
        "[blue]Generated files:[/blue]"
    )
    for filename in file_templates:
        console.print(f"  • {target_dir / filename}")


@cli.command()
@click.argument("problem_id", required=False)
@click.option("--force", is_flag=True, help="Force rebuild the Docker image")
@format_option
def setup(
    problem_id: str | None = None, force: bool = False, task_format: str = "apex"
):
    """Setup the Apex Arena environment."""
    do_setup(problem_id, force, task_format=task_format)


@cli.command()
@click.argument("problem_id")
@click.option("--model", default="starburst", help="Model to use for testing")
@click.option("--max_tokens", default=8000, help="Max tokens to use for testing")
@format_option
def grade(problem_id: str, model: str, max_tokens: int, task_format: str = "apex"):
    """Grade a specific problem."""
    do_grade(problem_id, model, max_tokens, task_format=task_format)


@cli.command()
@click.option(
    "--tasks",
    help="Comma-separated list of tasks to evaluate, or 'all' for all tasks",
)
@click.option("--runs", default=3, help="Number of runs per task")
@click.option("--model", default="starburst", help="Model to use for evaluation")
@click.option("--max_tokens", default=8000, help="Max tokens per evaluation")
@click.option("--max_turns", default=800, help="Max conversation turns per evaluation")
@click.option("--concurrency", default=3, help="Maximum concurrent evaluations")
@click.option("--output", default="eval_results.json", help="Output JSON file")
@click.option(
    "--debug", is_flag=True, help="Enable debug mode (disables live progress bar)"
)
@click.option(
    "--no-stream",
    is_flag=True,
    help="Disable streaming results to server (streaming is enabled by default)",
)
@click.option(
    "--server-url",
    help="Apex UI server URL (defaults to APEX_SERVER_URL env var or https://apex-ui-v2-319533213591.us-central1.run.app/)",
)
@click.option(
    "--api-key",
    help="Worker API key for authentication (defaults to APEX_API_KEY env var)",
)
@click.option(
    "--force-build",
    is_flag=True,
    help="Force rebuild the Docker image",
)
@click.option(
    "--enable-computer-use",
    is_flag=True,
    help="Enable the 'computer' tool for task execution (disabled by default)",
)
@click.option(
    "--agent",
    type=str,
    default=None,
    help="Agent type (format-specific). Use --format to see supported agents.",
)
@format_option
def eval(
    tasks: str,
    runs: int,
    model: str,
    max_tokens: int,
    max_turns: int,
    concurrency: int,
    output: str,
    debug: bool,
    no_stream: bool,
    server_url: str,
    api_key: str,
    force_build: bool = False,
    enable_computer_use: bool = False,
    agent: str = None,
    task_format: str = "apex",
):
    """Run evaluations across multiple tasks and aggregate results."""
    # Check for updates silently
    check_for_updates_silently()

    # Validate agent for format
    try:
        agent = validate_agent_for_format(agent, task_format)
    except click.BadParameter as e:
        console.print(f"[red]Error: {e.message}[/red]")
        sys.exit(1)

    from .eval_runner import EvalRunner

    # Configure streaming
    stream_results = not no_stream
    if stream_results:
        # Get server URL and API key from args or environment
        if not server_url:
            server_url = os.getenv(
                "APEX_SERVER_URL",
                "https://apex-ui-v2-319533213591.us-central1.run.app/",
            )
        if not api_key:
            api_key = os.getenv("APEX_API_KEY")

        if not api_key:
            console.print(
                "[yellow]Warning: No API key provided. Use --api-key or set APEX_API_KEY environment variable.[/yellow]"
            )
            console.print("[yellow]Disabling streaming...[/yellow]")
            stream_results = False

    # Discover available tasks
    runner = EvalRunner(task_format=task_format)
    available_tasks = runner.discover_tasks()

    if not available_tasks:
        console.print("[red]No valid tasks found in tasks/ directory[/red]")
        return

    # Parse task selection
    if not tasks:
        tasks = "all"

    if tasks.lower() == "all":
        selected_tasks = available_tasks
    else:
        selected_tasks = [s.strip() for s in tasks.split(",")]
        # Validate selections
        invalid = [s for s in selected_tasks if s not in available_tasks]
        if invalid:
            console.print(f"[red]Invalid tasks: {', '.join(invalid)}[/red]")
            console.print(f"[blue]Available tasks:[/blue] {', '.join(available_tasks)}")
            return

    console.print(
        f"[green]Running evaluation on {len(selected_tasks)} tasks with {runs} runs each[/green]"
    )

    # Run the evaluation
    asyncio.run(
        do_eval(
            selected_tasks,
            runs,
            model,
            max_tokens,
            max_turns,
            concurrency,
            output,
            debug,
            stream_results,
            server_url,
            api_key,
            force_build=force_build,
            task_versions=None,  # Local tasks don't have versions
            enable_computer_use=enable_computer_use,
            agent_type=agent,
            task_format=task_format,
        )
    )


@cli.group()
def tasks():
    """Manage tasks in Apex Arena."""
    pass


@cli.group()
def evaluations():
    """Run and manage evaluations."""
    pass


@evaluations.command("run")
@click.argument("task_ids", required=False)
@click.option(
    "--task-file",
    type=click.Path(exists=True, path_type=Path),
    help="Path to file containing task IDs (one per line)",
)
@click.option("--runs", default=3, help="Number of runs per task")
@click.option("--model", default="starburst", help="Model to use for evaluation")
@click.option("--max_tokens", default=4096, help="Max tokens per evaluation")
@click.option("--max_turns", default=800, help="Max conversation turns per evaluation")
@click.option("--concurrency", default=3, help="Maximum concurrent evaluations")
@click.option("--output", default="eval_results.json", help="Output JSON file")
@click.option(
    "--debug", is_flag=True, help="Enable debug mode (disables live progress bar)"
)
@click.option(
    "--no-stream",
    is_flag=True,
    help="Disable streaming results to server (streaming is enabled by default)",
)
@click.option(
    "--server-url",
    help="Apex UI server URL (defaults to APEX_SERVER_URL env var or https://apex-ui-v2-319533213591.us-central1.run.app/)",
)
@click.option(
    "--api-key",
    help="Worker API key for authentication (defaults to APEX_API_KEY env var)",
)
@click.option(
    "--force-build",
    is_flag=True,
    help="Force rebuild the Docker image",
)
@click.option(
    "--skip-validation",
    is_flag=True,
    help="Skip validation checks (both quality and structure) before running evaluation",
)
@click.option(
    "--evaluation-id",
    help="Existing evaluation ID to add rollouts to (skips creating new evaluation)",
)
@click.option(
    "--cleanup-existing",
    is_flag=True,
    help="Clean up existing apex-arena containers before starting evaluation",
)
@click.option(
    "--enable-computer-use",
    is_flag=True,
    help="Enable the 'computer' tool for task execution (disabled by default)",
)
@click.option(
    "--agent",
    type=str,
    default=None,
    help="Agent type (format-specific). Use --format to see supported agents.",
)
@click.option(
    "--cpus",
    type=float,
    default=-1,
    help="Number of CPUs to allocate per container. Use -1 for all cores (default).",
)
@click.option(
    "--no-cleanup",
    is_flag=True,
    help="Keep containers running after evaluation completes (useful for debugging)",
)
@click.option(
    "--run-index",
    type=int,
    default=None,
    help="Run only a specific run (0-based index). Used for parallel Cloud Batch execution.",
)
@format_option
def run_evaluation(
    task_ids: str,
    task_file: Path,
    runs: int,
    model: str,
    max_tokens: int,
    max_turns: int,
    concurrency: int,
    output: str,
    debug: bool,
    no_stream: bool,
    server_url: str,
    api_key: str,
    force_build: bool = False,
    skip_validation: bool = False,
    evaluation_id: str = None,
    cleanup_existing: bool = False,
    enable_computer_use: bool = False,
    agent: str = None,
    cpus: float = -1,
    no_cleanup: bool = False,
    run_index: int = None,
    task_format: str = "auto",
):
    """Run evaluations on specified local tasks or remote tasks."""
    # Configure inotify limits for file watching
    configure_inotify()

    # Check for updates silently
    check_for_updates_silently()

    try:
        from .task_resolver import get_tasks_dir, parse_task_ids, resolve_tasks
        from .utils import detect_task_format

        # Handle task IDs from file or command line argument
        if task_file and task_ids:
            console.print(
                "[red]Error: Cannot specify both task_ids and --task-file.[/red]"
            )
            sys.exit(1)

        if task_file:
            # Read task IDs from file
            try:
                with open(task_file, "r") as f:
                    task_id_list = [line.strip() for line in f if line.strip()]
                console.print(
                    f"[blue]Loaded {len(task_id_list)} task IDs from {task_file}[/blue]"
                )
            except Exception as e:
                console.print(f"[red]Error reading task file: {e}[/red]")
                sys.exit(1)
        elif task_ids:
            # Parse task IDs from command line
            task_id_list = parse_task_ids(task_ids)
        else:
            console.print(
                "[red]Error: Must specify either task IDs or --task-file.[/red]"
            )
            console.print(
                "[yellow]Usage: apex-arena evaluations run task1,task2,task3[/yellow]"
            )
            console.print(
                "[yellow]   or: apex-arena evaluations run --task-file target_tasks.txt[/yellow]"
            )
            sys.exit(1)

        if not task_id_list:
            console.print("[red]Error: No task IDs found.[/red]")
            sys.exit(1)

        tasks_dir = get_tasks_dir()
        console.print(f"[blue]Using tasks directory: {tasks_dir}[/blue]")
        console.print(f"[blue]Resolving {len(task_id_list)} task(s)...[/blue]")

        # Resolve task IDs to local tasks (download remote tasks if needed)
        resolve_result = resolve_tasks(task_id_list, task_format=task_format)
        resolved_tasks = resolve_result["tasks"]
        task_versions = resolve_result["task_versions"]
        updated_tasks = resolve_result.get("updated_tasks", [])

        console.print(
            f"[green]✓ Resolved {len(resolved_tasks)} task(s): {', '.join(resolved_tasks)}[/green]"
        )

        # Auto-detect format if needed
        if task_format == "auto":
            if resolved_tasks:
                first_task_dir = tasks_dir / resolved_tasks[0]
                detected_format = detect_task_format(first_task_dir)
                if detected_format:
                    task_format = detected_format
                    console.print(
                        f"[green]✓ Detected task format: {task_format}[/green]"
                    )
                else:
                    console.print("[red]Error: Could not detect task format.[/red]")
                    console.print(
                        "[yellow]Specify format with --format apex or --format harbor[/yellow]"
                    )
                    sys.exit(1)
            else:
                console.print(
                    "[red]Error: No tasks resolved for format detection.[/red]"
                )
                sys.exit(1)

        # Validate agent for format
        try:
            agent = validate_agent_for_format(agent, task_format)
        except click.BadParameter as e:
            console.print(f"[red]Error: {e.message}[/red]")
            sys.exit(1)

        # Configure streaming (same logic as existing eval command)
        stream_results = not no_stream
        if stream_results:
            # Get server URL and API key from args or environment
            if not server_url:
                server_url = os.getenv(
                    "APEX_SERVER_URL",
                    "https://apex-ui-v2-319533213591.us-central1.run.app/",
                )
            if not api_key:
                api_key = os.getenv("APEX_API_KEY")

            if not api_key:
                console.print(
                    "[yellow]Warning: No API key provided. Use --api-key or set APEX_API_KEY environment variable.[/yellow]"
                )
                console.print("[yellow]Disabling streaming...[/yellow]")
                stream_results = False

        # Run the evaluation using existing infrastructure
        console.print(
            f"[green]Running evaluation on {len(resolved_tasks)} tasks with {runs} runs each[/green]"
        )

        # Use the existing do_eval function with resolved tasks
        asyncio.run(
            do_eval(
                resolved_tasks,
                runs,
                model,
                max_tokens,
                max_turns,
                concurrency,
                output,
                debug,
                stream_results,
                server_url,
                api_key,
                force_build=force_build,
                skip_validation=skip_validation,
                task_versions=task_versions,
                evaluation_id=evaluation_id,
                cleanup_existing=cleanup_existing,
                enable_computer_use=enable_computer_use,
                agent_type=agent,
                updated_tasks=updated_tasks,
                cpus=cpus,
                no_cleanup=no_cleanup,
                task_format=task_format,
                run_index=run_index,
            )
        )

    except ImportError:
        console.print(
            "[red]Error: requests library is required. Install with: pip install requests[/red]"
        )
        sys.exit(1)
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error running evaluation: {e}[/red]")
        sys.exit(1)


@tasks.command("list")
def list_tasks():
    """List all tasks for authenticated user."""
    try:
        from .api_client import get_api_client

        api_client = get_api_client()

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description="Fetching tasks...", total=None)
            tasks_data = api_client.list_tasks()

        if not tasks_data:
            console.print("[yellow]No tasks found.[/yellow]")
            return

        # Create table to display tasks
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("ID", style="dim", width=8)
        table.add_column("Name", style="cyan")
        table.add_column("Status", width=10)

        # Check if admin fields are present (only for admin users)
        has_admin_fields = tasks_data and (
            "pushed_to_taiga" in tasks_data[0]
            or "passed_quality_check" in tasks_data[0]
        )
        if has_admin_fields:
            table.add_column("Quality Check", width=12)
            table.add_column("Pushed to Taiga", width=14)

        table.add_column("Created", style="dim")
        table.add_column("Creator", style="dim")

        for task in tasks_data:
            # Truncate ID for display
            task_id = (
                task.get("id", "")[:8] + "..."
                if len(task.get("id", "")) > 8
                else task.get("id", "")
            )

            # Format status with colors
            status = task.get("status", "N/A")
            if status == "active":
                status = f"[green]{status}[/green]"
            elif status == "inactive":
                status = f"[red]{status}[/red]"

            # Format date
            date_created = task.get("date_created", "")
            if date_created:
                # Extract just the date part
                date_created = (
                    date_created.split("T")[0] if "T" in date_created else date_created
                )

            # Build row data
            row_data = [
                task_id,
                task.get("name", "N/A"),
                status,
            ]

            # Add admin fields if present
            if has_admin_fields:
                quality_check = (
                    "[green]✓[/green]"
                    if task.get("passed_quality_check")
                    else "[red]✗[/red]"
                )
                pushed_to_taiga = (
                    "[green]✓[/green]"
                    if task.get("pushed_to_taiga")
                    else "[red]✗[/red]"
                )
                row_data.extend([quality_check, pushed_to_taiga])

            # Add common fields
            row_data.extend([date_created, task.get("creator_email", "N/A")])

            table.add_row(*row_data)

        console.print(f"\n[bold]Found {len(tasks_data)} tasks:[/bold]")
        console.print(table)

    except ImportError:
        console.print(
            "[red]Error: requests library is required. Install with: pip install requests[/red]"
        )
        sys.exit(1)
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        console.print("[yellow]Please set APEX_API_KEY environment variable.[/yellow]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error fetching tasks: {e}[/red]")
        sys.exit(1)


@tasks.command("download")
@click.argument("task_ids", required=False)
@click.option(
    "--task-file",
    type=click.Path(exists=True, path_type=Path),
    help="Path to file containing task IDs (one per line)",
)
@click.option(
    "--tasks-dir",
    type=click.Path(path_type=Path),
    help="Directory to download tasks into (defaults to APEX_TASK_DIR env var or ./tasks)",
)
@click.option(
    "--concurrency",
    default=10,
    help="Maximum number of concurrent downloads (default: 10)",
)
def download_tasks(task_ids: str, task_file: Path, tasks_dir: Path, concurrency: int):
    """Download tasks by their IDs (local names or remote UUIDs).

    Examples:
        apex-arena tasks download task1-uuid,task2-uuid
        apex-arena tasks download --task-file tasks.txt
        apex-arena tasks download task1,task2 --tasks-dir /custom/path
        apex-arena tasks download --task-file tasks.txt --concurrency 5
    """
    try:
        from .task_resolver import (
            get_tasks_dir,
            parse_task_ids,
        )

        # Handle task IDs from file or command line
        if task_file and task_ids:
            console.print(
                "[red]Error: Cannot specify both task_ids and --task-file.[/red]"
            )
            sys.exit(1)

        if task_file:
            # Read task IDs from file
            try:
                with open(task_file, "r") as f:
                    task_id_list = [line.strip() for line in f if line.strip()]
                console.print(
                    f"[blue]Loaded {len(task_id_list)} task IDs from {task_file}[/blue]"
                )
            except Exception as e:
                console.print(f"[red]Error reading task file: {e}[/red]")
                sys.exit(1)
        elif task_ids:
            # Parse task IDs from command line
            task_id_list = parse_task_ids(task_ids)
        else:
            # Interactive mode - prompt for task IDs
            console.print("[cyan]Enter task IDs to download (comma-separated):[/cyan]")
            task_ids_input = Prompt.ask("Task IDs")
            task_id_list = parse_task_ids(task_ids_input)

        if not task_id_list:
            console.print("[red]Error: No task IDs provided.[/red]")
            sys.exit(1)

        # Set tasks directory
        if tasks_dir is None:
            tasks_dir = get_tasks_dir()

        # Ensure tasks directory exists
        tasks_dir.mkdir(parents=True, exist_ok=True)

        console.print(f"[blue]Tasks directory: {tasks_dir}[/blue]")
        console.print(
            f"[blue]Processing {len(task_id_list)} task(s) with concurrency={concurrency}...[/blue]\n"
        )

        # Run async download function
        results = asyncio.run(
            _download_tasks_async(task_id_list, tasks_dir, concurrency)
        )

        # Extract results
        successful = results["successful"]
        skipped = results["skipped"]
        failed = results["failed"]

        # Print summary
        console.print("\n" + "=" * 60)
        console.print("[bold]Download Summary[/bold]")
        console.print("=" * 60)

        if successful:
            console.print(
                f"\n[green]✓ Successfully downloaded ({len(successful)}):[/green]"
            )
            for task in successful:
                console.print(f"  • {task}")

        if skipped:
            console.print(f"\n[yellow]⊘ Skipped ({len(skipped)}):[/yellow]")
            for task in skipped:
                console.print(f"  • {task}")

        if failed:
            console.print(f"\n[red]✗ Failed ({len(failed)}):[/red]")
            for task in failed:
                console.print(f"  • {task}")

        console.print("\n" + "=" * 60)
        total = len(successful) + len(skipped) + len(failed)
        console.print(
            f"[dim]Total: {total} | "
            f"Downloaded: {len(successful)} | "
            f"Skipped: {len(skipped)} | "
            f"Failed: {len(failed)}[/dim]"
        )

        if failed:
            sys.exit(1)

    except ImportError as e:
        console.print(f"[red]Error importing required modules: {e}[/red]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Unexpected error: {e}[/red]")
        sys.exit(1)


async def _download_tasks_async(
    task_id_list: list, tasks_dir: Path, max_concurrency: int
) -> dict:
    """Async function to download tasks concurrently."""
    from .task_resolver import (
        download_remote_task,
        is_local_task,
        is_remote_task,
        is_valid_uuid,
    )

    # Track results
    successful = []
    skipped = []
    failed = []

    # Create a semaphore for concurrency control
    semaphore = asyncio.Semaphore(max_concurrency)

    async def download_single_task(task_id: str) -> None:
        """Download a single task with semaphore control."""
        async with semaphore:
            task_id = task_id.strip()
            if not task_id:
                return

            try:
                # Run blocking operations in thread pool
                loop = asyncio.get_event_loop()

                # Check if already exists locally
                is_local = await loop.run_in_executor(
                    None, is_local_task, task_id, tasks_dir
                )

                if is_local:
                    if is_valid_uuid(task_id):
                        # For UUID tasks, check if update available
                        console.print(
                            f"[dim]Task {task_id} exists locally, checking for updates...[/dim]"
                        )
                        try:
                            result = await loop.run_in_executor(
                                None, download_remote_task, task_id, tasks_dir
                            )
                            version = result.get("task_version_id", "unknown")
                            successful.append(f"{task_id} (updated to v{version})")
                        except Exception as e:
                            console.print(
                                f"[yellow]Could not check for updates: {e}[/yellow]"
                            )
                            skipped.append(f"{task_id} (already exists locally)")
                    else:
                        console.print(
                            f"[yellow]Local task {task_id} already exists[/yellow]"
                        )
                        skipped.append(f"{task_id} (local task)")
                else:
                    # Check if remote task
                    is_remote = await loop.run_in_executor(
                        None, is_remote_task, task_id
                    )

                    if is_remote:
                        # Download remote task
                        console.print(
                            f"[cyan]Downloading remote task: {task_id}[/cyan]"
                        )
                        result = await loop.run_in_executor(
                            None, download_remote_task, task_id, tasks_dir
                        )
                        version = result.get("task_version_id", "unknown")
                        successful.append(f"{task_id} (v{version})")
                        console.print(f"[green]✓ Downloaded: {task_id}[/green]")
                    else:
                        console.print(f"[red]Task not found: {task_id}[/red]")
                        failed.append(f"{task_id} (not found)")

            except Exception as e:
                console.print(f"[red]Error processing {task_id}: {e}[/red]")
                failed.append(f"{task_id} ({str(e)[:50]}...)")

    # Create tasks for all downloads
    tasks = [download_single_task(task_id) for task_id in task_id_list]

    # Run all tasks concurrently
    await asyncio.gather(*tasks, return_exceptions=True)

    return {"successful": successful, "skipped": skipped, "failed": failed}


@tasks.command("update")
@click.argument("task_id")
@click.argument(
    "directory", type=click.Path(exists=True, file_okay=False, path_type=Path)
)
@click.option("--skip-validation", is_flag=True, help="Skip grader validation")
def update_task(task_id: str, directory: Path, skip_validation: bool):
    """Update an existing task with new files from a directory."""
    try:
        from .api_client import get_api_client
        from .quality_checker import QualityChecker
        from .utils import detect_task_format

        if not task_id or not task_id.strip():
            console.print("[red]Error: Task ID cannot be empty.[/red]")
            sys.exit(1)

        task_id = task_id.strip()

        console.print(
            f"[blue]Updating task '{task_id}' with files from: {directory}[/blue]"
        )

        # Auto-detect task format
        task_format = detect_task_format(directory)
        if not task_format:
            console.print("[red]Error: Could not detect task format.[/red]")
            console.print("[yellow]Directory must contain either:[/yellow]")
            console.print("  - Apex format: task.yaml and grader.py")
            console.print("  - Harbor format: task.toml and instruction.md")
            sys.exit(1)

        console.print(f"[green]✓ Detected task format: {task_format}[/green]")

        # Check format consistency with existing task
        api_client = get_api_client()
        try:
            existing_task = api_client.get_task(task_id)
            original_format = existing_task.get("format")
            if original_format and original_format != task_format:
                console.print(
                    f"[red]Error: Cannot change task format from '{original_format}' to '{task_format}'.[/red]"
                )
                console.print(
                    f"[yellow]Task {task_id} was created as a {original_format} task. Create a new task instead.[/yellow]"
                )
                sys.exit(1)
        except Exception as e:
            # If we can't get the task info, skip format validation (legacy task)
            console.print(f"[dim]Could not verify original format: {e}[/dim]")

        # Validation for both Apex and Harbor formats
        if not skip_validation:
            # Determine format-specific paths
            if task_format == "harbor":
                grader_path = directory / "tests" / "test.sh"
                solution_path = directory / "solution" / "solve.sh"
                grader_name = "tests/test.sh"
                solution_name = "solution/solve.sh"
            else:  # apex
                grader_path = directory / "grader.py"
                solution_path = directory / "solution.sh"
                grader_name = "grader.py"
                solution_name = "solution.sh"

            if grader_path.exists():
                console.print(f"[yellow]Running quality check ({task_format} format)...[/yellow]")

                # Run quality check with format-aware checker
                quality_checker = QualityChecker(directory, "biggie-plus", task_format=task_format)
                validation_result = asyncio.run(quality_checker.check())

                # Save validation report as report.json in the task directory
                report_path = directory / "report.json"
                try:
                    with open(report_path, "w", encoding="utf-8") as f:
                        json.dump(validation_result, f, indent=2, ensure_ascii=False)
                    console.print(
                        f"[blue]📄 Validation report saved: {report_path}[/blue]"
                    )
                except Exception as e:
                    console.print(
                        f"[yellow]⚠️ Could not save validation report: {e}[/yellow]"
                    )

                # Display validation results
                console.print("\n[bold]Quality Check Report:[/bold]")

                if "error" in validation_result:
                    console.print(
                        f"[red]❌ Quality check failed: {validation_result.get('error', 'Unknown error')}[/red]"
                    )
                    if not Confirm.ask(
                        "Continue with update despite quality check error?",
                        default=False,
                    ):
                        console.print("[yellow]Update cancelled.[/yellow]")
                        return
                else:
                    # Display formatted results
                    formatted_results = quality_checker.format_results(
                        validation_result
                    )
                    # Split into lines and indent for display
                    for line in formatted_results.split("\n"):
                        if line.strip():
                            console.print(f"  {line}")

                    # Check for failed checks
                    failed_checks = sum(
                        1
                        for key in validation_result
                        if key != "_metadata"
                        and isinstance(validation_result[key], dict)
                        and validation_result[key].get("outcome") == "fail"
                    )

                    if failed_checks > 0:
                        console.print(
                            f"\n[red]❌ {failed_checks} quality issues found[/red]"
                        )
                        if not Confirm.ask(
                            "Continue with update despite quality issues?",
                            default=False,
                        ):
                            console.print("[yellow]Update cancelled.[/yellow]")
                            return
                    else:
                        console.print("\n[green]✅ Quality check passed![/green]")
            else:
                console.print(
                    f"[yellow]Warning: No {grader_name} found in task directory[/yellow]"
                )
                if not Confirm.ask("Continue without quality check?", default=False):
                    console.print("[yellow]Update cancelled.[/yellow]")
                    return

            # Test solution if it exists
            if solution_path.exists():
                console.print(f"[yellow]Testing {solution_name}...[/yellow]")

                # Run the test-solution command internally
                try:
                    test_task_id = directory.name
                    console.print(
                        f"[dim]Running: apex-arena test-solution {test_task_id}[/dim]"
                    )

                    # Determine the proper working directory
                    # If directory is /path/to/tasks/hello-world, we need to run from /path/to
                    if directory.parent.name == "tasks":
                        run_cwd = directory.parent.parent
                    else:
                        # If directory is /some/path/hello-world, assume /some/path has tasks/ subdirectory
                        run_cwd = directory.parent

                    test_result = subprocess.run(
                        [
                            sys.executable,
                            "-m",
                            "apex_arena.cli",
                            "test-solution",
                            test_task_id,
                        ],
                        capture_output=True,
                        text=True,
                        cwd=run_cwd,
                    )

                    if test_result.returncode == 0:
                        console.print(
                            "[green]✓ Solution test passed! Solution achieves full score.[/green]"
                        )
                        # Show full stdout for successful tests too
                        if test_result.stdout:
                            console.print(
                                f"[dim]Full stdout:\n{test_result.stdout}[/dim]"
                            )
                        if test_result.stderr:
                            console.print(
                                f"[dim]Full stderr:\n{test_result.stderr}[/dim]"
                            )
                    else:
                        console.print(
                            f"[red]✗ Solution test failed! You cannot update the task when {solution_name} fails.[/red]"
                        )
                        if test_result.stdout:
                            console.print(
                                f"[dim]Full stdout:\n{test_result.stdout}[/dim]"
                            )
                        if test_result.stderr:
                            console.print(
                                f"[dim]Full stderr:\n{test_result.stderr}[/dim]"
                            )
                        return

                except Exception as e:
                    console.print(
                        f"[red]Error testing solution: {e}. You cannot update the task when {solution_name} fails.[/red]"
                    )
                    return
            else:
                console.print(
                    f"[red]Warning: No {solution_name} found in task directory. You cannot update the task without {solution_name}.[/red]"
                )
                return

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description="Uploading updated files...", total=None)
            result = api_client.update_task(task_id, directory, task_format=task_format)

        console.print("[green]✓ Task updated successfully![/green]")
        console.print(f"[dim]Task ID: {result.get('id', task_id)}[/dim]")
        if "date_updated" in result:
            console.print(f"[dim]Updated: {result['date_updated']}[/dim]")

    except ImportError:
        console.print(
            "[red]Error: requests library is required. Install with: pip install requests[/red]"
        )
        sys.exit(1)
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        if "APEX_API_KEY" in str(e):
            console.print(
                "[yellow]Please set APEX_API_KEY environment variable.[/yellow]"
            )
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error updating task: {e}[/red]")
        sys.exit(1)


@tasks.command("push")
@click.argument(
    "directory", type=click.Path(exists=True, file_okay=False, path_type=Path)
)
@click.option("--name", help="Task name (defaults to directory name)")
@click.option(
    "--spec",
    type=str,
    help="Specification ID to assign the task to (defaults to APEX_SPEC_ID env var)",
)
@click.option(
    "--skip-spec-confirmation",
    is_flag=True,
    help="Skip confirmation prompt for spec assignment",
)
@click.option("--skip-validation", is_flag=True, help="Skip grader validation")
@click.option("--skip-checklist", is_flag=True, help="Skip terminal tasks checklist")
def push_task(
    directory: Path,
    name: str,
    spec: Optional[str],
    skip_spec_confirmation: bool,
    skip_validation: bool,
    skip_checklist: bool,
):
    """Push a task directory to GCS with validation and quality checklist."""
    try:
        from .api_client import get_api_client
        from .quality_checker import QualityChecker
        from .utils import detect_task_format

        # Use provided name or default to directory name
        if not name:
            default_name = directory.name
            console.print(f"[dim]Directory: {directory}[/dim]")
            name = Prompt.ask("Enter task name", default=default_name)
        else:
            console.print(f"[dim]Directory: {directory}[/dim]")
            console.print(f"[dim]Task name: {name}[/dim]")

        if not name or not name.strip():
            console.print("[red]Task name cannot be empty.[/red]")
            sys.exit(1)

        name = name.strip()

        # Auto-detect task format
        task_format = detect_task_format(directory)
        if not task_format:
            console.print("[red]Error: Could not detect task format.[/red]")
            console.print("[yellow]Directory must contain either:[/yellow]")
            console.print("  - Apex format: task.yaml and grader.py")
            console.print("  - Harbor format: task.toml and instruction.md")
            sys.exit(1)

        console.print(f"[green]✓ Detected task format: {task_format}[/green]")

        # Validation for both Apex and Harbor formats
        if not skip_validation:
            # Determine format-specific paths
            if task_format == "harbor":
                grader_path = directory / "tests" / "test.sh"
                solution_path = directory / "solution" / "solve.sh"
                grader_name = "tests/test.sh"
                solution_name = "solution/solve.sh"
            else:  # apex
                grader_path = directory / "grader.py"
                solution_path = directory / "solution.sh"
                grader_name = "grader.py"
                solution_name = "solution.sh"

            if grader_path.exists():
                console.print(f"[yellow]Running quality check ({task_format} format)...[/yellow]")

                # Run quality check with format-aware checker
                quality_checker = QualityChecker(directory, "biggie-plus", task_format=task_format)
                validation_result = asyncio.run(quality_checker.check())

                # Save validation report as report.json in the task directory
                report_path = directory / "report.json"
                try:
                    with open(report_path, "w", encoding="utf-8") as f:
                        json.dump(validation_result, f, indent=2, ensure_ascii=False)
                    console.print(
                        f"[blue]📄 Validation report saved: {report_path}[/blue]"
                    )
                except Exception as e:
                    console.print(
                        f"[yellow]⚠️ Could not save validation report: {e}[/yellow]"
                    )

                # Display validation results
                console.print("\n[bold]Quality Check Report:[/bold]")

                if "error" in validation_result:
                    console.print(
                        f"[red]❌ Quality check failed: {validation_result.get('error', 'Unknown error')}[/red]"
                    )
                    if not Confirm.ask(
                        "Continue with upload despite quality check error?",
                        default=False,
                    ):
                        console.print("[yellow]Upload cancelled.[/yellow]")
                        return
                else:
                    # Display formatted results
                    formatted_results = quality_checker.format_results(
                        validation_result
                    )
                    # Split into lines and indent for display
                    for line in formatted_results.split("\n"):
                        if line.strip():
                            console.print(f"  {line}")

                    # Check for failed checks
                    failed_checks = sum(
                        1
                        for key in validation_result
                        if key != "_metadata"
                        and isinstance(validation_result[key], dict)
                        and validation_result[key].get("outcome") == "fail"
                    )

                    if failed_checks > 0:
                        console.print(
                            f"\n[red]❌ {failed_checks} quality issues found[/red]"
                        )
                        if not Confirm.ask(
                            "Continue with upload despite quality issues?",
                            default=False,
                        ):
                            console.print("[yellow]Upload cancelled.[/yellow]")
                            return
                    else:
                        console.print("\n[green]✅ Quality check passed![/green]")
            else:
                console.print(
                    f"[red]No {grader_name} found in task directory. You cannot upload the task without {grader_name}.[/red]"
                )
                return

            # Test solution if it exists (test-solution command handles both formats)
            if solution_path.exists():
                console.print(f"[yellow]Testing {solution_name}...[/yellow]")

                # Run the test-solution command internally
                try:
                    task_id = directory.name
                    console.print(
                        f"[dim]Running: apex-arena test-solution {task_id}[/dim]"
                    )

                    # Determine the proper working directory
                    # If directory is /path/to/tasks/hello-world, we need to run from /path/to
                    if directory.parent.name == "tasks":
                        run_cwd = directory.parent.parent
                    else:
                        # If directory is /some/path/hello-world, assume /some/path has tasks/ subdirectory
                        run_cwd = directory.parent

                    test_result = subprocess.run(
                        [
                            sys.executable,
                            "-m",
                            "apex_arena.cli",
                            "test-solution",
                            task_id,
                        ],
                        capture_output=True,
                        text=True,
                        cwd=run_cwd,
                    )

                    if test_result.returncode == 0:
                        console.print(
                            "[green]✓ Solution test passed! Solution achieves full score.[/green]"
                        )
                        # Show full stdout for successful tests too
                        if test_result.stdout:
                            console.print(
                                f"[dim]Full stdout:\n{test_result.stdout}[/dim]"
                            )
                        if test_result.stderr:
                            console.print(
                                f"[dim]Full stderr:\n{test_result.stderr}[/dim]"
                            )
                    else:
                        console.print(
                            f"[red]✗ Solution test failed! You cannot upload the task when {solution_name} fails.[/red]"
                        )
                        if test_result.stdout:
                            console.print(
                                f"[dim]Full stdout:\n{test_result.stdout}[/dim]"
                            )
                        if test_result.stderr:
                            console.print(
                                f"[dim]Full stderr:\n{test_result.stderr}[/dim]"
                            )
                        return

                except Exception as e:
                    console.print(
                        f"[red]Error testing solution: {e}. You cannot upload the task when {solution_name} fails.[/red]"
                    )
                    return
            else:
                console.print(
                    f"[red]No {solution_name} found in task directory. You cannot upload the task without {solution_name}.[/red]"
                )
                return

        # Terminal tasks checklist (apex format only)
        if task_format == "apex" and not skip_checklist:
            console.print("\n" + "=" * 80)
            console.print("[bold cyan]Terminal Tasks Checklist[/bold cyan]")
            console.print("Please confirm all items below before uploading your task:")
            console.print("=" * 80)

            checklist_items = [
                "All behavior checked in the test cases is described in the task instruction.",
                "All behavior described in the task instruction is checked in the unit tests.",
                "My test cases have informative docstrings that describe which behavior they check.",
                "It is hard for the agent to cheat on my task (e.g. by editing data files, looking inside files for strings that represent solutions, training on the test set, etc.).",
                "My task.yaml was written by a human.",
                "My solution.sh was written by a human (with minimal help from a language model).",
            ]

            console.print("[yellow]Please make sure EVERYTHING checks:[/yellow]\n")

            for i, item in enumerate(checklist_items, 1):
                console.print(f"[white]{i}.[/white] {item}")

            console.print("\n" + "=" * 80)

            if not Confirm.ask(
                "[bold]Do all items in the checklist apply to your task?[/bold]",
                default=False,
            ):
                console.print(
                    "[yellow]Upload cancelled. Please ensure your task meets all checklist requirements.[/yellow]"
                )
                return

            console.print("[green]✓ Checklist confirmed![/green]\n")

        api_client = get_api_client()

        # Handle spec validation and confirmation
        if not spec:
            # Try to get default spec from environment variable
            spec = os.getenv("APEX_SPEC_ID", "00000000-0000-0000-0000-000000000000")
            if spec != "00000000-0000-0000-0000-000000000000":
                console.print(f"[dim]Using spec from APEX_SPEC_ID: {spec}[/dim]")
        try:
            console.print(f"[yellow]Validating spec ID: {spec}[/yellow]")
            spec_info = api_client.get_spec(spec)

            if not skip_spec_confirmation:
                console.print(
                    "\n[bold]Task will be created with the following specification:[/bold]"
                )
                console.print(
                    f"  Spec Name: [cyan]{spec_info.get('name', 'N/A')}[/cyan]"
                )
                console.print(
                    f"  Project: [cyan]{spec_info.get('project_name', 'N/A')}[/cyan]"
                )
                console.print(f"  Spec ID: [dim]{spec_info.get('id', 'N/A')}[/dim]")

                if not Confirm.ask(
                    "\n[bold]Do you want to continue?[/bold]", default=True
                ):
                    console.print("[yellow]Task upload cancelled.[/yellow]")
                    return
            else:
                console.print(
                    f"[green]✓ Spec validated: {spec_info.get('name', 'N/A')}[/green]"
                )

        except Exception as e:
            error_msg = str(e)
            if "404" in error_msg or "not found" in error_msg.lower():
                console.print(f"[red]Error: Spec '{spec}' not found.[/red]")
                console.print(
                    "[yellow]Please check the spec ID and try again.[/yellow]"
                )
            elif "403" in error_msg or "forbidden" in error_msg.lower():
                console.print(
                    f"[red]Error: You do not have permission to use spec '{spec}'.[/red]"
                )
                console.print(
                    "[yellow]You must be assigned to a spec before creating tasks with it.[/yellow]"
                )
            else:
                console.print(f"[red]Error validating spec: {error_msg}[/red]")
            sys.exit(1)

        console.print(
            f"[yellow]Uploading task '{name}' from directory: {directory}[/yellow]"
        )

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description="Uploading files...", total=None)
            result = api_client.upload_task(
                directory, name, spec_id=spec, task_format=task_format
            )

        console.print("[green]✓ Task uploaded successfully![/green]")
        console.print(f"[dim]Task ID: {result['id']}[/dim]")
        console.print(f"[dim]Created: {result['date_created']}[/dim]")

        # Display spec information if available
        if result.get("spec_name"):
            console.print(f"[dim]Spec: {result['spec_name']}[/dim]")
        if result.get("project_name"):
            console.print(f"[dim]Project: {result['project_name']}[/dim]")

    except ImportError:
        console.print(
            "[red]Error: requests library is required. Install with: pip install requests[/red]"
        )
        sys.exit(1)
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        if "APEX_API_KEY" in str(e):
            console.print(
                "[yellow]Please set APEX_API_KEY environment variable.[/yellow]"
            )
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error uploading task: {e}[/red]")
        sys.exit(1)


@cli.command()
@click.argument("grader_path", type=click.Path(exists=True, path_type=Path))
def validate_grader(grader_path: Path):
    """Validate a grader.py file for potential issues."""
    try:
        from .quality_checker import QualityChecker

        # Determine if grader_path is a task directory or a grader file
        if grader_path.is_file() and grader_path.name == "grader.py":
            task_dir = grader_path.parent
        elif grader_path.is_dir():
            task_dir = grader_path
        else:
            console.print(
                "[red]Error: Path must be either a task directory or a grader.py file[/red]"
            )
            sys.exit(1)

        console.print(f"[blue]Running quality check on: {task_dir.name}[/blue]")

        # Run quality check
        quality_checker = QualityChecker(task_dir, "biggie-plus")
        validation_result = asyncio.run(quality_checker.check())

        # Display results
        if "error" in validation_result:
            console.print(
                f"[red]❌ Quality check failed: {validation_result.get('error', 'Unknown error')}[/red]"
            )
            sys.exit(1)

        # Format and display results
        formatted_results = quality_checker.format_results(validation_result)
        console.print(formatted_results)

        # Check if any critical issues found
        failed_checks = sum(
            1
            for key in validation_result
            if key != "_metadata"
            and isinstance(validation_result[key], dict)
            and validation_result[key].get("outcome") == "fail"
        )

        if failed_checks > 3:  # More than 3 failed checks is concerning
            console.print(
                "\n[red]❌ Multiple quality issues detected - consider significant improvements[/red]"
            )
            sys.exit(1)
        elif failed_checks > 0:
            console.print(
                f"\n[yellow]⚠️  {failed_checks} quality issue(s) detected - consider addressing them[/yellow]"
            )
        else:
            console.print("\n[green]✅ Quality check passed - no issues found![/green]")

    except Exception as e:
        console.print(f"[red]Error running quality check: {e}[/red]")
        sys.exit(1)


@cli.command()
@click.argument("task_path", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--model", default="biggie-plus", help="Model to use for quality checking"
)
def check_quality(task_path: Path, model: str):
    """Check the quality of a task (task.yaml, grader.py, Dockerfile)."""
    try:
        from .quality_checker import QualityChecker

        # Determine if task_path is a task directory or a grader file
        if task_path.is_file() and task_path.name == "grader.py":
            task_dir = task_path.parent
        elif task_path.is_dir():
            task_dir = task_path
        else:
            console.print(
                "[red]Error: Task path must be either a task directory or a grader.py file[/red]"
            )
            sys.exit(1)

        console.print(f"[blue]Running quality check on task: {task_dir.name}[/blue]")
        console.print(f"[dim]Task directory: {task_dir}[/dim]")
        console.print(f"[dim]Model: {model}[/dim]")

        # Initialize quality checker
        quality_checker = QualityChecker(task_dir, model)

        # Run quality check
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task(description="Running quality check...", total=None)
            results = asyncio.run(quality_checker.check())

        # Display results
        if "error" in results:
            console.print(f"[red]❌ Quality check failed: {results['error']}[/red]")
            if "raw_response" in results:
                console.print("[yellow]Raw LLM response:[/yellow]")
                console.print(Panel(results["raw_response"], title="LLM Response"))
            sys.exit(1)

        # Format and display results
        formatted_results = quality_checker.format_results(results)
        console.print(
            Panel(formatted_results, title=f"Quality Check Results - {task_dir.name}")
        )

        # Check if any critical issues found
        failed_checks = sum(
            1
            for key in results
            if key != "_metadata"
            and isinstance(results[key], dict)
            and results[key].get("outcome") == "fail"
        )

        if failed_checks > 3:  # More than 3 failed checks is concerning
            console.print(
                "\n[red]❌ Multiple quality issues detected - consider significant improvements[/red]"
            )
            sys.exit(1)
        elif failed_checks > 0:
            console.print(
                f"\n[yellow]⚠️  {failed_checks} quality issue(s) detected - consider addressing them[/yellow]"
            )
        else:
            console.print("\n[green]✅ Quality check passed - no issues found![/green]")

    except ImportError as e:
        console.print(f"[red]Error importing quality checker: {e}[/red]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error running quality check: {e}[/red]")
        import traceback

        console.print(f"[dim]{traceback.format_exc()}[/dim]")
        sys.exit(1)


@cli.group()
def tools():
    """Interact with MCP server tools."""
    pass


@tools.command("list")
@click.option(
    "--server-url",
    default="http://localhost:8001/mcp/",
    help="MCP server URL",
)
def list_server_tools(server_url: str):
    """List all available tools on an MCP server."""
    console.print(f"[blue]Connecting to MCP server at: {server_url}[/blue]")
    asyncio.run(list_tools(server_url))


@tools.command("call")
@click.argument("tool_name")
@click.option(
    "--server-url",
    default="http://localhost:8001/mcp/",
    help="MCP server URL",
)
@click.option(
    "--args",
    help='JSON string of tool arguments (e.g. \'{"key": "value"}\')',
)
def call_tool_cmd(tool_name: str, server_url: str, args: str):
    """Call a specific tool on an MCP server."""
    console.print(f"[blue]Connecting to MCP server at: {server_url}[/blue]")

    # Parse arguments
    tool_args = {}
    if args:
        try:
            tool_args = json.loads(args)
        except json.JSONDecodeError as e:
            console.print(f"[red]Invalid JSON in args: {e}[/red]")
            console.print('[yellow]Example: --args \'{"problem_id": "test"}\'[/yellow]')
            sys.exit(1)

    asyncio.run(do_tool_call(server_url, tool_name, tool_args))


@cli.command()
@click.argument(
    "folder_path", type=click.Path(exists=True, file_okay=False, path_type=Path)
)
def check_anatomy(folder_path: Path):
    """Check if a task folder has the correct anatomy/structure."""
    try:
        from .utils import validate_task_folder_structure

        console.print(f"[blue]Checking task folder anatomy: {folder_path}[/blue]")
        console.print("[dim]Expected structure:[/dim]")
        console.print(
            "[dim]Required files: Dockerfile, grader.py, solution.sh, task.yaml[/dim]"
        )
        console.print("[dim]Optional files: report.json, .apex_metadata.json[/dim]")
        console.print("[dim]Optional folders: data/, tests/, __pycache__/[/dim]")
        console.print("[dim]No other files or folders are allowed.[/dim]\n")

        is_valid, errors = validate_task_folder_structure(folder_path)

        if is_valid:
            console.print("[green]✅ Task folder structure is valid![/green]")
            console.print(
                "[green]All required files are present and no unexpected files/folders found.[/green]"
            )
            sys.exit(0)
        else:
            console.print("[red]❌ Task folder structure is invalid![/red]")
            console.print(f"[red]Found {len(errors)} issue(s):[/red]\n")

            for i, error in enumerate(errors, 1):
                console.print(f"[red]{i}. {error}[/red]")

            console.print(
                "\n[yellow]Please fix these issues to ensure the task folder meets the required structure.[/yellow]"
            )
            sys.exit(1)

    except Exception as e:
        console.print(f"[red]Error checking task anatomy: {e}[/red]")
        sys.exit(1)


def _parse_harbor_reward(jobs_dir: Path, job_name: str) -> float:
    """Parse reward from Harbor job output.

    Harbor writes to: <jobs_dir>/<job_name>/<run_id>/verifier/reward.txt (or reward.json)
    """
    job_dir = jobs_dir / job_name

    if not job_dir.exists():
        console.print(f"[yellow]⚠️ Job directory not found: {job_dir}[/yellow]")
        return 0.0

    # Find verifier directory (inside run_id subdirectory)
    verifier_dir = None
    for subdir in job_dir.iterdir():
        if subdir.is_dir():
            candidate = subdir / "verifier"
            if candidate.exists():
                verifier_dir = candidate
                break

    if not verifier_dir:
        console.print(f"[yellow]⚠️ No verifier directory found in {job_dir}[/yellow]")
        return 0.0

    # Try reward.txt first (simple float score)
    reward_txt = verifier_dir / "reward.txt"
    if reward_txt.exists():
        try:
            return float(reward_txt.read_text().strip())
        except ValueError as e:
            console.print(f"[yellow]⚠️ Failed to parse reward.txt: {e}[/yellow]")

    # Fall back to reward.json
    reward_json = verifier_dir / "reward.json"
    if reward_json.exists():
        try:
            data = json.load(open(reward_json))
            if isinstance(data, dict):
                # Get 'score' key if present
                if "score" in data:
                    return float(data["score"])
                # Average all numeric values
                values = [v for v in data.values() if isinstance(v, (int, float))]
                if values:
                    return sum(values) / len(values)
        except (json.JSONDecodeError, ValueError) as e:
            console.print(f"[yellow]⚠️ Failed to parse reward.json: {e}[/yellow]")

    console.print(f"[yellow]⚠️ No reward file found in {verifier_dir}[/yellow]")
    return 0.0


def _display_verifier_logs(jobs_dir: Path, job_name: str, verbose: bool = False):
    """Display verifier logs from Harbor job output.

    Args:
        jobs_dir: Path to the jobs directory
        job_name: Name of the job
        verbose: If True, show full log contents; otherwise show summary
    """
    job_dir = jobs_dir / job_name

    if not job_dir.exists():
        return

    # Find verifier directory (inside run_id subdirectory)
    verifier_dir = None
    run_dir = None
    for subdir in job_dir.iterdir():
        if subdir.is_dir():
            candidate = subdir / "verifier"
            if candidate.exists():
                verifier_dir = candidate
                run_dir = subdir
                break

    if not verifier_dir:
        return

    # Display paths to log files
    console.print("\n[bold cyan]📂 Log Files:[/bold cyan]")
    console.print(f"  [dim]Job directory:[/dim] {job_dir}")
    console.print(f"  [dim]Verifier directory:[/dim] {verifier_dir}")

    # List all files in verifier directory
    log_files = []
    for file_path in sorted(verifier_dir.iterdir()):
        if file_path.is_file():
            log_files.append(file_path)
            console.print(f"  [dim]- {file_path.name}[/dim]")

    # Also check for agent logs if they exist
    if run_dir:
        agent_dir = run_dir / "agent"
        if agent_dir.exists():
            console.print(f"  [dim]Agent directory:[/dim] {agent_dir}")
            for file_path in sorted(agent_dir.iterdir()):
                if file_path.is_file():
                    console.print(f"  [dim]- {file_path.name}[/dim]")

    # Display log contents
    important_logs = ["test-stdout.txt", "test-stderr.txt", "reward.json", "reward.txt"]

    if verbose:
        # Show all logs in verbose mode
        console.print("\n[bold cyan]📋 Log Contents:[/bold cyan]")
        for file_path in log_files:
            try:
                content = file_path.read_text().strip()
                if content:
                    console.print(f"\n[bold yellow]── {file_path.name} ──[/bold yellow]")
                    # Truncate very long logs
                    if len(content) > 5000:
                        content = content[:5000] + "\n... [truncated, see file for full output]"
                    console.print(content)
            except Exception as e:
                console.print(f"  [red]Error reading {file_path.name}: {e}[/red]")
    else:
        # In non-verbose mode, show important logs only
        for log_name in important_logs:
            log_path = verifier_dir / log_name
            if log_path.exists():
                try:
                    content = log_path.read_text().strip()
                    if content:
                        console.print(f"\n[bold yellow]── {log_name} ──[/bold yellow]")
                        # Show limited output
                        lines = content.split("\n")
                        if len(lines) > 50:
                            console.print("\n".join(lines[:25]))
                            console.print(f"\n... [{len(lines) - 50} lines omitted] ...\n")
                            console.print("\n".join(lines[-25:]))
                            console.print(f"\n[dim]See full output: {log_path}[/dim]")
                        else:
                            console.print(content)
                except Exception as e:
                    console.print(f"  [red]Error reading {log_name}: {e}[/red]")


def _test_solution_harbor(task_id: str, task_dir: Path, force: bool = False, verbose: bool = False):
    """Test a Harbor format task by running with oracle agent.

    Args:
        task_id: Task identifier
        task_dir: Path to the task directory
        force: Force rebuild the Docker image
        verbose: Show detailed logs during and after execution
    """
    import os

    console.print(f"\n[bold cyan]🧪 Testing Harbor Task: {task_id}[/bold cyan]\n")
    console.print("[dim]Detected Harbor format (task.toml + instruction.md)[/dim]\n")

    # Step 1: Validate solution/solve.sh exists
    solve_sh = task_dir / "solution" / "solve.sh"
    if not solve_sh.exists():
        console.print(f"[red]❌ solution/solve.sh not found in {task_dir}[/red]")
        console.print(
            "[yellow]📝 Harbor tasks must have solution/solve.sh to test with oracle agent[/yellow]"
        )
        sys.exit(1)

    console.print("✅ Found solution/solve.sh")

    # Step 2: Create persistent job output directory (under tasks/.cache)
    # This allows inspection of logs after the test completes
    cache_dir = task_dir.parent / ".cache" / task_id
    jobs_dir = cache_dir / "jobs"
    jobs_dir.mkdir(parents=True, exist_ok=True)
    job_name = f"test_{task_id}"

    # Clear old job results to avoid confusion with stale data
    old_job_dir = jobs_dir / job_name
    if old_job_dir.exists():
        import shutil
        console.print(f"[dim]Clearing previous test results from {old_job_dir}[/dim]")
        shutil.rmtree(old_job_dir)

    # Step 3: Build harbor run command
    cmd = [
        "harbor",
        "run",
        "-p",
        str(task_dir.absolute()),
        "-a",
        "oracle",
        "--jobs-dir",
        str(jobs_dir),
        "--job-name",
        job_name,
    ]
    if force:
        cmd.append("--force-build")

    console.print(f"🚀 Running: {' '.join(cmd)}")
    console.print(f"[dim]Job output will be saved to: {jobs_dir / job_name}[/dim]\n")

    # Step 4: Execute with real-time output streaming
    timeout = int(os.getenv("TEST_SOLUTION_TIMEOUT", "1800"))
    returncode = None

    try:
        # Use Popen for real-time streaming output
        process = subprocess.Popen(
            cmd,
            stdout=None,  # Stream directly to parent's stdout
            stderr=None,  # Stream directly to parent's stderr
        )

        try:
            returncode = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            console.print(f"\n[red]❌ Timeout after {timeout}s[/red]")
            console.print(f"[yellow]📂 Check logs at: {jobs_dir / job_name}[/yellow]")
            _display_verifier_logs(jobs_dir, job_name, verbose)
            sys.exit(1)

    except FileNotFoundError:
        console.print(
            "[red]❌ Harbor CLI not found. Install with: pip install harbor[/red]"
        )
        sys.exit(1)

    # Step 5: Handle non-zero exit code
    if returncode != 0:
        console.print(
            f"\n[red]❌ Harbor run failed with exit code {returncode}[/red]"
        )
        console.print(f"[yellow]📂 Check logs at: {jobs_dir / job_name}[/yellow]")
        _display_verifier_logs(jobs_dir, job_name, verbose=True)  # Always verbose on failure
        sys.exit(1)

    # Step 6: Parse reward from job output
    score = _parse_harbor_reward(jobs_dir, job_name)

    # Step 7: Display logs if verbose or if score is not perfect
    if verbose or score < 1.0:
        _display_verifier_logs(jobs_dir, job_name, verbose)

    # Step 8: Report result
    console.print(f"\n🎯 [bold]Final Score: {score}[/bold]")
    console.print(f"[dim]📂 Job output saved at: {jobs_dir / job_name}[/dim]")

    if score >= 1.0:
        console.print(
            "🌟 [bold green]SUCCESS: Oracle solution achieved full score![/bold green]"
        )
    elif score >= 0.8:
        console.print(
            f"⚠️ [bold yellow]PARTIAL: Score {score} (expected 1.0)[/bold yellow]"
        )
        sys.exit(1)
    else:
        console.print(f"❌ [bold red]FAILURE: Score {score} != 1.0[/bold red]")
        sys.exit(1)


@cli.command()
@click.argument("task_id")
@click.option("--force", is_flag=True, help="Force rebuild the Docker image")
@click.option("--keep-container", is_flag=True, help="Keep container running after test for debugging")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed logs during and after execution")
@click.option("--no-server", is_flag=True, help="Skip MCP server startup (faster, allows parallel runs)")
def test_solution(task_id: str, force: bool = False, keep_container: bool = False, verbose: bool = False, no_server: bool = False):
    """Test a task by running its solution.sh and verifying it gets full score.

    For Harbor format tasks, output is streamed in real-time and logs are displayed
    at the end. Use --verbose for more detailed log output.

    Use --no-server for faster execution and to allow parallel batch testing
    (skips MCP server startup and port allocation).
    """

    import os

    # Configure inotify limits for file watching
    configure_inotify()

    console.print(f"\n[bold cyan]🧪 Testing Solution for Task: {task_id}[/bold cyan]\n")

    # Check if task exists
    task_dir = Path("tasks") / task_id
    if not task_dir.exists():
        console.print(f"[red]❌ Task directory not found: {task_dir}[/red]")
        sys.exit(1)

    # Detect task format (Harbor vs Apex)
    task_toml = task_dir / "task.toml"
    instruction_md = task_dir / "instruction.md"
    is_harbor_format = task_toml.exists() and instruction_md.exists()

    if is_harbor_format:
        _test_solution_harbor(task_id, task_dir, force, verbose)
        return

    # Apex format: continue with existing logic
    grader_path = task_dir / "grader.py"
    solution_path = task_dir / "solution.sh"
    setup_path = task_dir / "setup.sh"

    # Check required files
    if not grader_path.exists():
        console.print(f"[red]❌ grader.py not found in {task_dir}[/red]")
        sys.exit(1)

    if not solution_path.exists():
        console.print(f"[red]❌ solution.sh not found in {task_dir}[/red]")
        console.print(
            "[yellow]📝 Tasks must have a solution.sh file that achieves full score[/yellow]"
        )
        sys.exit(1)

    # Check if solution.sh is executable
    if not os.access(solution_path, os.X_OK):
        console.print("[yellow]⚠️  solution.sh is not executable, fixing...[/yellow]")
        os.chmod(solution_path, 0o755)

    try:
        # Step 1: Build the task container (without starting server)
        console.print("📦 [bold blue]Step 1:[/bold blue] Building task container...")

        try:
            # Use the build_docker_image function which only builds, doesn't start server
            container_name = build_docker_image(
                task_id, force_base=force, force_task=force
            )
            console.print(f"✅ Task container ready: {container_name}")
        except Exception as e:
            console.print(f"[red]❌ Container build failed: {e}[/red]")
            sys.exit(1)

        # Step 2: Check and fix solution.sh format before running
        console.print("🔍 Checking solution.sh format...")

        # Make setup.sh executable if it exists
        if setup_path.exists() and not os.access(setup_path, os.X_OK):
            console.print("[yellow]⚠️  setup.sh is not executable, fixing...[/yellow]")
            os.chmod(setup_path, 0o755)

        try:
            with open(solution_path, "rb") as f:
                content = f.read()

            # Check for Windows line endings and fix them
            if b"\r\n" in content:
                console.print(
                    "[yellow]⚠️  Converting Windows line endings to Unix...[/yellow]"
                )
                content = content.replace(b"\r\n", b"\n")
                with open(solution_path, "wb") as f:
                    f.write(content)

            # Check for shebang
            content_text = content.decode("utf-8", errors="ignore")
            if not content_text.startswith("#!"):
                console.print(
                    "[yellow]⚠️  Adding shebang line to solution.sh...[/yellow]"
                )
                content_text = "#!/bin/bash\n" + content_text
                with open(solution_path, "w", encoding="utf-8") as f:
                    f.write(content_text)
                # Make executable again after modification
                os.chmod(solution_path, 0o755)

        except Exception as e:
            console.print(f"[yellow]⚠️  Could not check/fix solution.sh: {e}[/yellow]")

        # Step 3: Run setup.sh, solution.sh, and grader.py as separate commands in single container
        console.print(
            "🚀 [bold blue]Step 2:[/bold blue] Starting container for all steps..."
        )

        # Create grader script
        grader_script_content = """
import sys
import json
from typing import Dict, Optional, Any

# Create mock apex_arena module structure
class MockGradingResult:
    def __init__(self, score: float, subscores: Dict[str, float] = None,
                 weights: Dict[str, float] = None, feedback: Optional[str] = None,
                 details: Optional[Dict[str, Any]] = None):
        self.score = score
        self.subscores = subscores or {}
        self.weights = weights or {}
        self.feedback = feedback
        self.details = details

# Create mock module structure
class MockTypes:
    GradingResult = MockGradingResult

class MockApexArena:
    _types = MockTypes()

# Monkey patch into sys.modules before importing grader
sys.modules['apex_arena'] = MockApexArena()
sys.modules['apex_arena._types'] = MockTypes()

# Now we can safely import the grader (use current directory since we cd there)
import os
sys.path.insert(0, os.getcwd())
from grader import grade

try:
    result = grade("")
    # Convert GradingResult to dict for JSON serialization
    result_dict = {
        "score": result.score,
        "subscores": result.subscores,
        "weights": result.weights,
        "feedback": result.feedback
    }
    print(json.dumps(result_dict))
except Exception as e:
    print(json.dumps({"error": str(e), "score": 0.0}))
"""

        # Create a temporary grader script file
        import tempfile

        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(grader_script_content)
            temp_script_path = f.name

        # Build the execution script
        has_setup = setup_path.exists()

        # Use the mounted tasks directory for setup/grader, copy to /tmp for solution
        task_workdir = f"/mcp_server/tasks/{task_id}"
        solution_workdir = f"/tmp/task"

        setup_script_cmd = (
            f"cd {task_workdir} && chmod +x setup.sh && ./setup.sh"
        ) if has_setup else None

        # Copy entire task folder to /tmp so any user can access it
        copy_task_cmd = (
            f"cp -r {task_workdir} {solution_workdir} && "
            f"chmod -R 777 {solution_workdir}"
        )

        solution_script_cmd = f"cd {solution_workdir} && ./solution.sh"

        grader_script_cmd = f"cd {task_workdir} && python3 /tmp/grade_script.py"

        # Initialize entrypoint_log_file before try block to avoid NameError in exception handlers
        entrypoint_log_file = None
        log_process = None
        entrypoint_logs_printed = False  # Track if logs have been printed to avoid duplicates

        # Clean up any stale iptables rules from previous runs
        cleanup_stale_iptables_rules(silent=True)

        # Run everything in a container with network restrictions
        try:
            # Generate unique container name for this test run
            import time

            test_container_name = f"apex_test_{task_id}_{int(time.time())}"
            if keep_container:
                console.print(f"[dim]Container name: {test_container_name}[/dim]")

            if no_server:
                # Fast mode: skip MCP server, just keep container running
                console.print("[dim]Running in --no-server mode (faster, no port allocation)[/dim]")
                start_cmd = [
                    "docker",
                    "run",
                    "-d",  # Run in background
                    "--name",
                    test_container_name,
                    "--privileged",
                    "--cgroupns=private",
                    "-v",
                    f"{temp_script_path}:/tmp/grade_script.py:ro",
                    "-v",
                    f"{Path.cwd()}/tasks:/mcp_server/tasks",
                    "-e",
                    "MCP_TESTING_MODE=1",
                    container_name,
                    "tail", "-f", "/dev/null",  # Just keep container running
                ]
            else:
                # Start container exactly like eval_runner does
                # Run MCP server so we can poll for readiness the same way
                start_cmd = [
                    "docker",
                    "run",
                    "-d",  # Run in background
                    "--name",
                    test_container_name,
                    "--privileged",
                    "--cgroupns=private",
                    "-p",
                    "18001:8001",  # Expose MCP server port for health check
                    "-v",
                    f"{temp_script_path}:/tmp/grade_script.py:ro",
                    "-v",
                    f"{Path.cwd()}/tasks:/mcp_server/tasks",  # Match eval_runner
                    "-e",
                    "MCP_TESTING_MODE=1",  # Match eval_runner
                    container_name,
                    "sh",
                    "-c",
                    "python3 /mcp_server/apex_arena/server.py",  # Same as eval_runner
                ]

            start_result = subprocess.run(start_cmd, capture_output=True, text=True)

            if start_result.returncode != 0:
                console.print(
                    f"[red]❌ Failed to start container: {start_result.stderr}[/red]"
                )
                sys.exit(1)

            # Register cleanup handlers to ensure iptables rules are removed on exit
            register_container_cleanup(test_container_name)

            # Start capturing entrypoint logs (like eval_runner does)
            import tempfile
            entrypoint_log_dir = Path(tempfile.gettempdir()) / "apex-arena-logs"
            entrypoint_log_dir.mkdir(exist_ok=True)
            entrypoint_log_file = entrypoint_log_dir / f"{test_container_name}-entrypoint.log"

            try:
                log_stream = open(entrypoint_log_file, "w")
                # Start docker logs -f in background to capture all container output
                log_process = subprocess.Popen(
                    ["docker", "logs", "-f", test_container_name],
                    stdout=log_stream,
                    stderr=subprocess.STDOUT,
                )
            except Exception as e:
                console.print(f"[yellow]⚠️  Failed to start docker logs capture: {e}[/yellow]")
                entrypoint_log_file = None
                log_process = None

            if no_server:
                # In no-server mode, just wait a moment for container to be ready
                import time as time_module
                console.print("⏳ Waiting for container to be ready...")
                time_module.sleep(2)
                # Print entrypoint logs
                if entrypoint_log_file and entrypoint_log_file.exists():
                    _print_entrypoint_logs(entrypoint_log_file, "Entrypoint Logs (Container Ready - no-server mode)")
                    entrypoint_logs_printed = True
            else:
                # Wait for MCP server to be ready (same as eval_runner's wait_for_server_ready)
                # The MCP server only starts after entrypoint.sh completes all service setup
                console.print("⏳ Waiting for MCP server to be ready (up to 10 minutes)...")
                console.print(f"[dim]You can check logs with: docker logs -f {test_container_name}[/dim]")
                import time as time_module
                import httpx

                server_url = "http://localhost:18001/mcp"
                max_attempts = 360  # Same as eval_runner
                attempt = 0
                server_ready = False
                http_client = httpx.Client(timeout=10.0)

                while attempt < max_attempts:
                    attempt += 1
                    try:
                        response = http_client.get(server_url)
                        # Any valid HTTP response means server is up (same as eval_runner)
                        if response.status_code in [200, 404, 405, 406, 307]:
                            console.print(f"[green]✅ MCP server ready at {server_url} (attempt {attempt})[/green]")
                            server_ready = True
                            break
                    except Exception:
                        # Server not ready yet
                        if attempt % 6 == 0:  # Print every ~30-60 seconds
                            elapsed = attempt * 10 if attempt > 5 else attempt * 5
                            console.print(f"[dim]Waiting for server, be patient... (attempt {attempt}, ~{elapsed}s)[/dim]")

                    # Same timing as eval_runner: 5s for first 5 attempts, then 10s
                    if attempt < 5:
                        time_module.sleep(5)
                    else:
                        time_module.sleep(10)

                http_client.close()

                if not server_ready:
                    console.print("[red]❌ MCP server failed to start within 10 minutes[/red]")
                    console.print(f"[yellow]Check logs: docker logs {test_container_name}[/yellow]")
                    # Always print entrypoint logs on startup failure
                    if entrypoint_log_file and entrypoint_log_file.exists():
                        _print_entrypoint_logs(entrypoint_log_file, "Entrypoint Logs (STARTUP FAILED)")
                        entrypoint_logs_printed = True
                    if not keep_container:
                        subprocess.run(["docker", "rm", "-f", test_container_name], capture_output=True)
                    sys.exit(1)

                # Print entrypoint logs
                if entrypoint_log_file and entrypoint_log_file.exists():
                    time_module.sleep(0.5)  # Give a moment for logs to be flushed
                    _print_entrypoint_logs(entrypoint_log_file, "Entrypoint Logs (MCP Server Ready)")
                    entrypoint_logs_printed = True

            # Apply iptables rules to block internet
            try:
                # Get container IP and gateway
                result = subprocess.run(
                    [
                        "docker",
                        "inspect",
                        test_container_name,
                        "--format",
                        "{{range .NetworkSettings.Networks}}{{.IPAddress}},{{.Gateway}}{{end}}",
                    ],
                    capture_output=True,
                    text=True,
                )
                ip_info = result.stdout.strip().split(",")
                if len(ip_info) == 2:
                    container_ip = ip_info[0]
                    gateway_ip = ip_info[1]

                    # Apply iptables to block internet
                    iptables_script = f"""
apk add iptables >/dev/null 2>&1
# Insert in reverse order (last rule first, first rule last)
# Drop everything else (public internet) - insert last
iptables -I DOCKER-USER 1 -s {container_ip} -j DROP
# Allow to private networks (RFC1918)
iptables -I DOCKER-USER 1 -s {container_ip} -d 192.168.0.0/16 -j ACCEPT
iptables -I DOCKER-USER 1 -s {container_ip} -d 172.16.0.0/12 -j ACCEPT
iptables -I DOCKER-USER 1 -s {container_ip} -d 10.0.0.0/8 -j ACCEPT
# Allow DNS
iptables -I DOCKER-USER 1 -s {container_ip} -p tcp --dport 53 -j ACCEPT
iptables -I DOCKER-USER 1 -s {container_ip} -p udp --dport 53 -j ACCEPT
# Allow all traffic to Docker gateway (host) - insert first
iptables -I DOCKER-USER 1 -s {container_ip} -d {gateway_ip} -j ACCEPT
"""
                    subprocess.run(
                        [
                            "docker",
                            "run",
                            "--rm",
                            "--privileged",
                            "--net=host",
                            "alpine",
                            "sh",
                            "-c",
                            iptables_script,
                        ],
                        capture_output=True,
                        text=True,
                        timeout=60,  # Increased from 10s to allow alpine pull + iptables install
                    )
            except Exception as e:
                console.print(
                    f"[yellow]⚠️  Failed to apply network restrictions: {e}[/yellow]"
                )

            default_timeout = int(os.getenv("TEST_SOLUTION_TIMEOUT", 1800))
            solution_timeout = 5400  # 90 minutes for solution.sh
            console.print(f"Running with {default_timeout}s default timeout, {solution_timeout}s for solution.sh...")

            def run_docker_exec(script, description, user=None, fail_on_error=True, step_timeout=None):
                """Run a docker exec command and return result."""
                exec_timeout = step_timeout if step_timeout is not None else default_timeout
                user_str = f" (as {user})" if user else ""
                console.print(f"🔧 {description}{user_str}...")
                exec_cmd = ["docker", "exec"]
                if user:
                    exec_cmd.extend(["-u", user])
                exec_cmd.extend([test_container_name, "bash", "-c", script])
                result = subprocess.run(
                    exec_cmd, capture_output=True, text=True, timeout=exec_timeout
                )
                if result.stdout:
                    console.print(result.stdout)
                if result.returncode != 0 and fail_on_error:
                    console.print(f"[red]❌ {description} failed:[/red]")
                    if result.stderr:
                        console.print(f"stderr: {result.stderr}")
                    return None
                return result

            # Step 1: Run setup.sh
            if setup_script_cmd:
                result = run_docker_exec(setup_script_cmd, "Running setup.sh")
                if result is None:
                    sys.exit(1)

            # Step 2: Copy task folder to /tmp (so it's accessible)
            result = run_docker_exec(copy_task_cmd, "Copying task to /tmp")
            if result is None:
                sys.exit(1)

            # Step 3: Run solution.sh as non-root user (detect available user)
            result = run_docker_exec(
                "id ubuntu >/dev/null 2>&1 && echo ubuntu || (id model >/dev/null 2>&1 && echo model || echo nobody)",
                "Detecting non-root user"
            )
            nonroot_user = result.stdout.strip().split('\n')[-1] if result else "nobody"
            result = run_docker_exec(solution_script_cmd, "Running solution.sh", user=nonroot_user, step_timeout=solution_timeout)
            if result is None:
                sys.exit(1)

            # Step 4: Run grader.py
            result = run_docker_exec(grader_script_cmd, "Running grader.py")
            if result is None:
                sys.exit(1)

            console.print("✅ All steps completed successfully")

            # Parse the JSON result from grader output (last line)
            output_lines = result.stdout.strip().split("\n")
            json_output = output_lines[-1] if output_lines else "{}"

            try:
                grading_data = json.loads(json_output)

                if "error" in grading_data:
                    console.print(
                        f"[red]❌ Grading error: {grading_data['error']}[/red]"
                    )
                    sys.exit(1)

                # Use the same score extraction logic as eval runner
                score = extract_score_from_grade_result(grading_data)
                console.print(f"\n🎯 [bold]Final Score: {score}[/bold]")

                if score >= 1.0:
                    console.print(
                        "🌟 [bold green]SUCCESS: Solution achieved full score![/bold green]"
                    )
                elif score >= 0.8:
                    console.print(
                        "⚠️  [bold yellow]PARTIAL SUCCESS: Solution achieved good score but not perfect[/bold yellow]"
                    )
                    console.print(
                        "🔍 Consider improving the solution to get full score"
                    )
                else:
                    console.print(
                        "❌ [bold red]FAILURE: Solution did not achieve sufficient score[/bold red]"
                    )
                    console.print("🛠️  The solution.sh needs to be fixed")

                # Show detailed scoring if available
                if grading_data.get("subscores"):
                    console.print("\n📋 [bold]Detailed Scoring:[/bold]")
                    for key, value in grading_data["subscores"].items():
                        status = "✅" if value >= 1.0 else "⚠️" if value >= 0.5 else "❌"
                        console.print(f"  {status} {key}: {value}")

                # Show feedback if available
                if grading_data.get("feedback"):
                    console.print("\n💬 [bold]Feedback:[/bold]")
                    console.print(f"  {grading_data['feedback']}")

                # Exit with error code if solution didn't achieve full score
                if score < 1.0:
                    console.print(
                        f"\n❌ [bold red]Exiting with error: Solution score {score} < 1.0[/bold red]"
                    )
                    sys.exit(1)

            except json.JSONDecodeError as e:
                console.print(f"[red]❌ Failed to parse grading result: {e}[/red]")
                console.print(f"Raw output: {json_output}")
                # Print entrypoint logs on error (only if not already printed)
                if not entrypoint_logs_printed and entrypoint_log_file and entrypoint_log_file.exists():
                    _print_entrypoint_logs(entrypoint_log_file, "Entrypoint Logs (GRADING ERROR)")
                sys.exit(1)
            except Exception as e:
                console.print(f"[red]❌ Error during execution: {e}[/red]")
                import traceback

                traceback.print_exc()
                # Print entrypoint logs on error (only if not already printed)
                if not entrypoint_logs_printed and entrypoint_log_file and entrypoint_log_file.exists():
                    _print_entrypoint_logs(entrypoint_log_file, "Entrypoint Logs (EXECUTION ERROR)")
                sys.exit(1)

        except subprocess.TimeoutExpired as e:
            console.print(f"[red]❌ Container execution timed out: {e}[/red]")
            # Print entrypoint logs on timeout (only if not already printed)
            if not entrypoint_logs_printed and entrypoint_log_file and entrypoint_log_file.exists():
                _print_entrypoint_logs(entrypoint_log_file, "Entrypoint Logs (TIMEOUT)")
            sys.exit(1)
        except Exception as e:
            console.print(f"[red]❌ Unexpected error: {e}[/red]")
            import traceback

            traceback.print_exc()
            # Print entrypoint logs on error (only if not already printed)
            if not entrypoint_logs_printed and entrypoint_log_file and entrypoint_log_file.exists():
                _print_entrypoint_logs(entrypoint_log_file, "Entrypoint Logs (UNEXPECTED ERROR)")
            sys.exit(1)
        finally:
            # Clean up container and iptables rules
            try:
                # Get container IP before removing
                result = subprocess.run(
                    [
                        "docker",
                        "inspect",
                        test_container_name,
                        "--format",
                        "{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}",
                    ],
                    capture_output=True,
                    text=True,
                )
                container_ip = result.stdout.strip()

                if container_ip:
                    # Remove iptables rules for this container
                    cleanup_script = f"""
apk add iptables >/dev/null 2>&1
# Keep deleting rules until none match (handles multiple rules)
while iptables -L DOCKER-USER -n --line-numbers | grep -q {container_ip}; do
    line=$(iptables -L DOCKER-USER -n --line-numbers | grep {container_ip} | head -1 | awk '{{print $1}}')
    iptables -D DOCKER-USER $line
done
"""
                    subprocess.run(
                        [
                            "docker",
                            "run",
                            "--rm",
                            "--privileged",
                            "--net=host",
                            "alpine",
                            "sh",
                            "-c",
                            cleanup_script,
                        ],
                        capture_output=True,
                        text=True,
                        timeout=60,  # Increased from 10s to allow alpine pull
                    )

                # Remove container unless --keep-container flag is set
                if not keep_container:
                    subprocess.run(
                        ["docker", "rm", "-f", test_container_name],
                        capture_output=True,
                        text=True,
                    )
            except:
                pass

            # Clean up temporary script file
            try:
                os.unlink(temp_script_path)
            except:
                pass

        if keep_container:
            console.print(f"\n📦 [bold yellow]Container kept for debugging: {test_container_name}[/bold yellow]")
            console.print(f"[dim]Debug with: docker exec -it {test_container_name} bash[/dim]")
            console.print(f"[dim]Remove with: docker rm -f {test_container_name}[/dim]")

        console.print(
            f"\n✅ [bold green]Task solution testing completed for: {task_id}[/bold green]"
        )

    except subprocess.TimeoutExpired as e:
        console.print(f"[red]❌ Operation timed out: {e}[/red]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]❌ Unexpected error: {e}[/red]")
        sys.exit(1)


@cli.command("upload-harbor")
@click.argument("job_dir", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--upload-tasks",
    is_flag=True,
    help="Upload tasks to Apex before uploading rollouts",
)
@click.option(
    "--tasks-dir",
    type=click.Path(exists=True, path_type=Path),
    help="Path to Harbor tasks directory (required with --upload-tasks)",
)
@click.option(
    "--server-url",
    default=os.getenv("APEX_SERVER_URL", "https://apex-ui-v2-319533213591.us-central1.run.app/"),
    help="Apex UI server URL",
)
@click.option(
    "--api-key",
    default=os.getenv("APEX_API_KEY"),
    help="Apex API key (or set APEX_API_KEY env var)",
)
def upload_harbor(
    job_dir: Path,
    upload_tasks: bool,
    tasks_dir: Optional[Path],
    server_url: str,
    api_key: str,
):
    """Upload Harbor job trajectories to Apex UI dashboard.

    JOB_DIR is the path to a Harbor job directory containing trial subdirectories
    with trajectory.json files.

    Examples:
        apex upload-harbor /path/to/harbor/jobs/2026-01-06__22-29-16

        # Upload tasks first, then rollouts:
        apex upload-harbor /path/to/job --upload-tasks --tasks-dir /path/to/tasks
    """
    from .harbor_uploader import upload_harbor_job_sync

    if not api_key:
        console.print("[red]Error: APEX_API_KEY environment variable or --api-key required[/red]")
        sys.exit(1)

    if upload_tasks and not tasks_dir:
        console.print("[red]Error: --tasks-dir is required when using --upload-tasks[/red]")
        sys.exit(1)

    console.print(f"[bold cyan]Uploading Harbor trajectories to Apex[/bold cyan]")
    console.print(f"[dim]Server: {server_url}[/dim]")
    console.print(f"[dim]Job directory: {job_dir}[/dim]")
    if upload_tasks:
        console.print(f"[dim]Tasks directory: {tasks_dir}[/dim]")

    try:
        evaluation_id = upload_harbor_job_sync(
            server_url=server_url,
            api_key=api_key,
            job_dir=job_dir,
            tasks_dir=tasks_dir if upload_tasks else None,
            verbose=True,
        )

        if evaluation_id:
            console.print(f"\n[bold green]Upload complete![/bold green]")
            console.print(f"View evaluation: {server_url}/evaluations/{evaluation_id}")
        else:
            console.print("[yellow]No trajectories found to upload[/yellow]")
            sys.exit(1)

    except Exception as e:
        console.print(f"[red]Error uploading: {e}[/red]")
        sys.exit(1)


if __name__ == "__main__":
    cli()
