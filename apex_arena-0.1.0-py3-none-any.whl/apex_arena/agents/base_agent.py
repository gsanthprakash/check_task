from abc import ABC, abstractmethod
from typing import Dict, Any, Optional


class BaseAgent(ABC):
    """Base class for all agents in apex-arena."""
    
    def __init__(
        self,
        model: str,
        max_tokens: int,
        max_turns: int = 800,
        **kwargs
    ):
        self.model = model
        self.max_tokens = max_tokens
        self.max_turns = max_turns
        # Usage tracking accumulators
        self._total_input_tokens = 0
        self._total_output_tokens = 0
        self._total_cache_read_tokens = 0
        self._total_cache_write_tokens = 0
        self._total_cost = 0.0
        # Current context size (overwritten each call, not accumulated)
        self._current_context_tokens = 0
        # Turn count (incremented once per LLM call via _track_usage)
        self._turn_count = 0

    def _track_usage(self, response: dict):
        """Accumulate token usage and cost from an LLM response. Called once per LLM call."""
        if isinstance(response, dict):
            usage = response.get("usage") or {}
            input_tokens = usage.get("input_tokens", 0) or 0
            output_tokens = usage.get("output_tokens", 0) or 0
            cache_read = usage.get("cache_read_tokens", 0) or 0
            cache_write = usage.get("cache_write_tokens", 0) or 0

            self._total_input_tokens += input_tokens
            self._total_output_tokens += output_tokens
            self._total_cache_read_tokens += cache_read
            self._total_cache_write_tokens += cache_write
            self._total_cost += response.get("cost", 0.0) or 0.0
            # Current context = full prompt size for this call
            # input_tokens (uncached) + cache_read + cache_write = total prompt tokens
            self._current_context_tokens = input_tokens + cache_read + cache_write
            self._turn_count += 1

    def _get_usage_summary(self) -> Dict:
        """Return accumulated usage stats for the rollout."""
        return {
            "total_input_tokens": self._total_input_tokens,
            "total_output_tokens": self._total_output_tokens,
            "total_cache_read_tokens": self._total_cache_read_tokens,
            "total_cache_write_tokens": self._total_cache_write_tokens,
            "total_cost": self._total_cost,
            "current_context_tokens": self._current_context_tokens,
            "turn_count": self._turn_count,
        }

    @abstractmethod
    async def run_problem(
        self, 
        problem_id: str,
        session,  # MCP session
        logger_client=None  # Optional logger client for tracking
    ) -> Dict[str, Any]:
        """
        Run a problem using this agent.
        
        Args:
            problem_id: The ID of the problem to solve
            session: MCP session object
            logger_client: Optional logging client for transcript tracking
            
        Returns:
            Dict containing problem_id and grade_result
        """
        pass