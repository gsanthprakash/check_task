# Apex Arena Internal Flow

This diagram shows the internal architecture and data flow of the Apex Arena Python backend.

```mermaid
flowchart TD
    Start([User runs CLI]) --> CLI[cli.py]

    CLI -->|apex grade| Grade[Grade Command]
    CLI -->|apex eval| Eval[Eval Command]
    CLI -->|apex setup| Setup[Setup Command]

    Setup --> BuildImage[build_docker_image]
    BuildImage --> StartMCP[Start MCP Container]
    StartMCP --> MCPServer[server.py in container]

    Grade --> Tester[tester.py]
    Tester --> Agent{Agent Selection}

    Agent -->|starburst models| TerminusV1[TerminusV1Agent]
    Agent -->|other models| MCPAgent[MCPAgent]

    TerminusV1 --> ConnectMCP[Connect to MCP Server]
    MCPAgent --> ConnectMCP

    ConnectMCP --> SetupProblem[setup_problem tool]
    SetupProblem --> LoadTask[Load task.yaml]
    SetupProblem --> RunSetup[Run setup.sh if exists]
    SetupProblem --> LoadGrader[Load grader.py]

    LoadTask --> AgentLoop[Agent Loop]
    AgentLoop --> LLMCall[LLM Client]
    LLMCall --> Proxy[Proxy Server]
    Proxy -->|maps codename| RealModel[Real Model API]

    RealModel -->|biggie-plus| Claude4.5[Claude Opus 4.5]
    RealModel -->|starburst| Gemini2.5[Gemini 2.5 Pro]
    RealModel -->|astromax| MiniMax[MiniMax-M2]

    Claude4.5 --> Response[Model Response]
    Gemini2.5 --> Response
    MiniMax --> Response

    Response -->|tool calls| ExecuteTool[Execute MCP Tool]
    ExecuteTool -->|bash| BashTool[bash tool in container]
    ExecuteTool -->|str_replace_editor| EditTool[str_replace_editor tool]
    ExecuteTool -->|computer| ComputerTool[computer tool]

    BashTool -->|runs as uid=1000| Workdir[/workdir/ access only]
    EditTool -->|runs as uid=1000| Workdir
    ComputerTool -->|runs as uid=1000| Workdir

    Workdir --> ToolResult[Tool Result]
    ToolResult --> AgentLoop

    Response -->|done signal| CallGrader[grade_problem tool]
    AgentLoop -->|max turns| CallGrader

    CallGrader --> GraderPy[grader.py grade function]
    GraderPy --> Score[Return Score]

    Eval --> EvalRunner[eval_runner.py]
    EvalRunner --> DiscoverTasks[Discover Tasks]
    EvalRunner --> BuildImages[Build Task Images]
    BuildImages --> StartContainers[Start Multiple Containers]
    StartContainers --> ParallelRuns[Run Tasks in Parallel]
    ParallelRuns --> Tester
    Score --> Results[Aggregate Results]

    style MCPServer fill:#e1f5ff
    style BashTool fill:#ffe1e1
    style EditTool fill:#ffe1e1
    style ComputerTool fill:#ffe1e1
    style Workdir fill:#ffe1e1
    style GraderPy fill:#e1ffe1
    style Proxy fill:#fff4e1
```

## Key Security Boundaries

1. **MCP Tools Run as uid=1000**: All tools (bash, str_replace_editor, computer) run as the model user with limited permissions
2. **No Access to /mcp_server/**: Model cannot access task files, grader, or solutions stored in /mcp_server/
3. **Only /workdir/ Access**: Model can only read/write files in /workdir/ directory
4. **Network Isolation**: Docker containers have internet blocked by default via iptables

## Data Flow Summary

1. CLI parses commands and routes to appropriate handler
2. Docker images are built (base + task-specific)
3. MCP server starts in Docker container with network isolation
4. Agent connects to MCP server and calls setup_problem
5. Agent loop: LLM → Tool Calls → MCP Tools → Results → LLM
6. When done, grade_problem is called to score the solution
7. Results are returned and aggregated (for eval runs)
