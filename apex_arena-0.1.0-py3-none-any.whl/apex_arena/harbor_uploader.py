"""Upload Harbor trajectory files to Apex UI dashboard.

Usage:
    apex upload-harbor /path/to/harbor/job
    apex upload-harbor /path/to/harbor/job --upload-tasks --tasks-dir /path/to/tasks
"""

import asyncio
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

import aiohttp

from .api_client import ApexAPIClient
from .task_formats.harbor_trajectory_parser import parse_trajectory_to_messages


@dataclass
class TrialInfo:
    """Information about a Harbor trial."""

    trial_name: str
    task_name: str
    trajectory_path: Path
    reward: float
    agent_name: str
    model_name: str
    source: str


class HarborUploader:
    """Uploads Harbor trajectories to Apex UI."""

    def __init__(self, server_url: str, api_key: str):
        self.server_url = server_url.rstrip("/")
        self.api_key = api_key
        self.session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self):
        self.session = aiohttp.ClientSession(
            headers={"X-API-Key": self.api_key},
            timeout=aiohttp.ClientTimeout(total=120),
        )
        return self

    async def __aexit__(self, *args):
        if self.session:
            await self.session.close()

    async def start_evaluation(
        self,
        tasks: List[str],
        runs_per_task: int,
        model: str,
        agent_type: str = "claude-code",
    ) -> str:
        """Start a new evaluation and return the evaluation_id."""
        payload = {
            "tasks": tasks,
            "runs_per_task": runs_per_task,
            "model": model,
            "max_tokens": 8192,
            "max_concurrency": 1,
            "enable_computer_use": False,
            "agent_type": agent_type,
        }

        async with self.session.post(
            f"{self.server_url}/api/evaluations/start",
            json=payload,
        ) as response:
            if response.status != 200:
                error_text = await response.text()
                raise RuntimeError(
                    f"Failed to start evaluation: {response.status} - {error_text}"
                )
            result = await response.json()
            return result["evaluation_id"]

    async def create_rollout(
        self,
        evaluation_id: str,
        task_id: str,
        run_number: int,
        success: bool,
        score: float,
    ) -> str:
        """Create a rollout and return the rollout_id."""
        payload = {
            "local_task_id": task_id,
            "run_number": run_number,
            "success": success,
            "grade_result": {
                "score": score,
                "subscores": {"reward": score},
                "weights": {"reward": 1.0},
            },
            "extracted_score": score,
            "format": "harbor",
        }

        async with self.session.post(
            f"{self.server_url}/api/evaluations/{evaluation_id}/rollouts",
            json=payload,
        ) as response:
            if response.status != 200:
                error_text = await response.text()
                raise RuntimeError(
                    f"Failed to create rollout: {response.status} - {error_text}"
                )
            result = await response.json()
            return result["rollout_id"]

    async def upload_messages(
        self,
        evaluation_id: str,
        rollout_id: str,
        messages: List[Dict[str, Any]],
    ) -> int:
        """Upload messages for a rollout. Returns number of messages uploaded."""
        if not messages:
            return 0

        payload = {"rollout_id": rollout_id, "messages": messages}

        async with self.session.post(
            f"{self.server_url}/api/evaluations/{evaluation_id}/messages",
            json=payload,
        ) as response:
            if response.status != 200:
                error_text = await response.text()
                raise RuntimeError(
                    f"Failed to upload messages: {response.status} - {error_text}"
                )
            result = await response.json()
            return result.get("message_count", len(messages))

    async def complete_evaluation(self, evaluation_id: str) -> None:
        """Mark evaluation as completed."""
        async with self.session.post(
            f"{self.server_url}/api/evaluations/{evaluation_id}/complete",
            json={"status": "completed"},
        ) as response:
            if response.status != 200:
                error_text = await response.text()
                raise RuntimeError(
                    f"Failed to complete evaluation: {response.status} - {error_text}"
                )


def _parse_trial_metadata(result_path: Path, default_task_name: str) -> dict:
    """Parse trial metadata from result.json."""
    metadata = {
        "task_name": default_task_name,
        "reward": 0.0,
        "agent_name": "claude-code",
        "model_name": "unknown",
    }

    if result_path.exists():
        with open(result_path) as f:
            result = json.load(f)
            metadata["task_name"] = result.get("task_name", default_task_name)
            metadata["reward"] = (
                result.get("verifier_result", {}).get("rewards", {}).get("reward", 0.0)
            )
            metadata["agent_name"] = result.get("agent_info", {}).get("name", "claude-code")
            model_info = result.get("agent_info", {}).get("model_info", {})
            metadata["model_name"] = model_info.get("name", "unknown")

    return metadata


def _get_source_from_config(job_dir: Path) -> str:
    """Extract source/dataset name from job config."""
    config_path = job_dir / "config.json"
    if config_path.exists():
        with open(config_path) as f:
            config = json.load(f)
            datasets = config.get("datasets", [])
            if datasets:
                dataset_path = datasets[0].get("path", "")
                if "/" in dataset_path:
                    return dataset_path.split("/")[-1]
                return dataset_path or "harbor"
    return "harbor"


def _strip_trial_suffix(name: str) -> str:
    """Strip the random suffix from trial/job names (e.g., 'task__abc123' -> 'task')."""
    return name.rsplit("__", 1)[0] if "__" in name else name


def discover_trials(job_dir: Path) -> List[TrialInfo]:
    """Discover all trials with trajectories in a Harbor job directory.

    Handles both:
    - Job directory containing multiple trial subdirectories
    - Single trial directory (with agent/trajectory.json directly inside)
    """
    trials = []
    source = _get_source_from_config(job_dir)

    # Check if job_dir itself is a single trial directory
    direct_trajectory = job_dir / "agent" / "trajectory.json"
    if direct_trajectory.exists():
        meta = _parse_trial_metadata(job_dir / "result.json", job_dir.name)
        trials.append(
            TrialInfo(
                trial_name=job_dir.name,
                task_name=meta["task_name"],
                trajectory_path=direct_trajectory,
                reward=meta["reward"],
                agent_name=meta["agent_name"],
                model_name=meta["model_name"],
                source=source,
            )
        )
        return trials

    # Otherwise, iterate over trial subdirectories
    for trial_dir in sorted(job_dir.iterdir()):
        if not trial_dir.is_dir():
            continue

        trajectory_path = trial_dir / "agent" / "trajectory.json"
        if not trajectory_path.exists():
            continue

        meta = _parse_trial_metadata(trial_dir / "result.json", trial_dir.name)
        trials.append(
            TrialInfo(
                trial_name=trial_dir.name,
                task_name=meta["task_name"],
                trajectory_path=trajectory_path,
                reward=meta["reward"],
                agent_name=meta["agent_name"],
                model_name=meta["model_name"],
                source=source,
            )
        )

    return trials


def _infer_task_names(job_dir: Path, tasks_dir: Optional[Path]) -> Set[str]:
    """Infer task names when no trials are found."""
    # If tasks_dir is a single task (contains task.toml), use its name
    if tasks_dir and (tasks_dir / "task.toml").exists():
        return {tasks_dir.name}

    # Check if job_dir looks like a trial directory (has agent/ or verifier/)
    subdirs = {p.name for p in job_dir.iterdir() if p.is_dir()}
    if subdirs & {"agent", "verifier"}:
        return {_strip_trial_suffix(job_dir.name)}

    # Otherwise, infer from child directory names
    inferred = set()
    for child in job_dir.iterdir():
        if child.is_dir() and child.name not in {"agent", "verifier"}:
            inferred.add(_strip_trial_suffix(child.name))

    return inferred or {_strip_trial_suffix(job_dir.name)}


def upload_tasks(
    server_url: str,
    api_key: str,
    tasks_dir: Path,
    task_names: Set[str],
    verbose: bool = True,
) -> Dict[str, str]:
    """Upload Harbor tasks to Apex.

    Args:
        server_url: Apex UI server URL
        api_key: Apex API key
        tasks_dir: Path to tasks directory, or path to a single task
        task_names: Set of task names to upload
        verbose: Print progress messages

    Returns:
        Dict mapping task_name to task_id for successfully uploaded tasks
    """
    client = ApexAPIClient(server_url=server_url, api_key=api_key)
    uploaded: Dict[str, str] = {}

    # Check if tasks_dir is a single task (contains task.toml)
    is_single_task = (tasks_dir / "task.toml").exists()

    for task_name in sorted(task_names):
        task_path = tasks_dir if is_single_task else tasks_dir / task_name

        if not task_path.exists():
            if verbose:
                print(f"    Task not found: {task_path}, skipping")
            continue

        try:
            if verbose:
                print(f"    Uploading task: {task_name}")

            result = client.upload_task(
                directory=task_path,
                name=task_name,
                task_format="harbor",
            )

            task_id = (
                result.get("taskId")
                or result.get("task_id")
                or result.get("id")
                or result.get("taskVersionId")
            )
            uploaded[task_name] = task_id or task_name

            if verbose:
                print(f"      Uploaded: {task_id or '(no id returned)'}")

        except Exception as e:
            if verbose:
                print(f"      Failed: {e}")

    return uploaded


async def upload_harbor_job(
    server_url: str,
    api_key: str,
    job_dir: Path,
    tasks_dir: Optional[Path] = None,
    verbose: bool = True,
) -> Optional[str]:
    """Upload trajectories from a Harbor job directory to Apex.

    Args:
        server_url: Apex UI server URL
        api_key: Apex API key
        job_dir: Path to Harbor job directory (or single trial directory)
        tasks_dir: Optional path to tasks directory. If provided, tasks are
            uploaded before rollouts.
        verbose: Print progress messages

    Returns:
        Evaluation ID if successful, None otherwise
    """
    if verbose:
        print(f"Processing job: {job_dir.name}")

    trials = discover_trials(job_dir)
    if verbose:
        print(f"  Found {len(trials)} trials")

    # Get task names from trials, or infer them
    task_names = set(t.task_name for t in trials)
    if not task_names and tasks_dir:
        task_names = _infer_task_names(job_dir, tasks_dir)
        if verbose:
            print(f"  Inferred task names: {', '.join(sorted(task_names))}")

    # Upload tasks if requested
    if tasks_dir:
        if verbose:
            print(f"  Uploading {len(task_names)} task(s) from {tasks_dir}")
        uploaded = upload_tasks(server_url, api_key, tasks_dir, task_names, verbose)
        if verbose:
            print(f"  Uploaded {len(uploaded)} task(s)")

    # Exit if no rollouts to upload
    if not trials:
        if verbose:
            print(f"  No trajectories to upload")
        return None

    first = trials[0]
    runs_per_task = len(trials) // len(task_names) if task_names else 1

    if verbose:
        print(f"  Model: {first.model_name}, Agent: {first.agent_name}")

    async with HarborUploader(server_url, api_key) as uploader:
        evaluation_id = await uploader.start_evaluation(
            tasks=list(task_names),
            runs_per_task=runs_per_task,
            model=first.model_name,
            agent_type=first.agent_name,
        )

        if verbose:
            print(f"  Evaluation ID: {evaluation_id}")

        run_counts: Dict[str, int] = {}

        for trial in trials:
            run_number = run_counts.get(trial.task_name, 0) + 1
            run_counts[trial.task_name] = run_number

            if verbose:
                print(f"  Uploading {trial.trial_name} (run {run_number})")

            rollout_id = await uploader.create_rollout(
                evaluation_id=evaluation_id,
                task_id=trial.task_name,
                run_number=run_number,
                success=trial.reward > 0,
                score=trial.reward,
            )

            with open(trial.trajectory_path) as f:
                trajectory_data = json.load(f)

            messages = parse_trajectory_to_messages(trajectory_data)
            msg_count = await uploader.upload_messages(evaluation_id, rollout_id, messages)

            if verbose:
                print(f"    Uploaded {msg_count} messages")

        try:
            await uploader.complete_evaluation(evaluation_id)
            if verbose:
                print(f"  Evaluation completed: {evaluation_id}")
        except RuntimeError as e:
            # Server may auto-complete evaluations
            if "already completed" in str(e).lower():
                if verbose:
                    print(f"  Evaluation completed: {evaluation_id}")
            else:
                raise

    return evaluation_id


def upload_harbor_job_sync(
    server_url: str,
    api_key: str,
    job_dir: Path,
    tasks_dir: Optional[Path] = None,
    verbose: bool = True,
) -> Optional[str]:
    """Synchronous wrapper for upload_harbor_job."""
    return asyncio.run(
        upload_harbor_job(server_url, api_key, job_dir, tasks_dir, verbose)
    )
