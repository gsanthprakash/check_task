import json
from typing import Any, Dict, List, Optional

import aiohttp
from rich.console import Console

console = Console()
import time


class ResultStreamer:
    """Handles streaming evaluation results to the Apex UI server."""

    def __init__(self, server_url: str, api_key: str):
        self.server_url = server_url.rstrip("/")
        self.api_key = api_key
        connector = aiohttp.TCPConnector(limit=10000)
        self.session = aiohttp.ClientSession(
            headers={"X-API-Key": self.api_key},
            timeout=aiohttp.ClientTimeout(total=60),
            connector=connector,
        )

    async def start_evaluation(
        self,
        tasks: List[str],
        runs_per_task: int,
        model: str,
        max_tokens: int,
        max_concurrency: int = 1,
        enable_computer_use: bool = False,
        agent_type: Optional[str] = None,
    ) -> str:
        """Start a new evaluation and return the evaluation_id."""
        if not self.session:
            raise RuntimeError(
                "ResultStreamer not properly initialized. Use async context manager."
            )

        payload = {
            "tasks": tasks,
            "runs_per_task": runs_per_task,
            "model": model,
            "max_tokens": max_tokens,
            "max_concurrency": max_concurrency,
            "enable_computer_use": enable_computer_use,
            "agent_type": agent_type,
        }

        try:
            async with self.session.post(
                f"{self.server_url}/api/evaluations/start", json=payload
            ) as response:
                if response.status == 401:
                    raise RuntimeError("Authentication failed. Check your API key.")
                elif response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(
                        f"Failed to start evaluation: {response.status} - {error_text}"
                    )

                result = await response.json()
                evaluation_id = result["evaluation_id"]
                console.print(f"[green]Started evaluation: {evaluation_id}[/green]")
                return evaluation_id

        except aiohttp.ClientError as e:
            raise RuntimeError(f"Network error starting evaluation: {e}")

    async def stream_rollout(
        self,
        evaluation_id: str,
        local_task_id: str,
        run_number: int,
        success: bool,
        grade_result: Any = None,
        extracted_score: Optional[float] = None,
        task_version_id: Optional[str] = None,
        format: str = "apex",
        total_input_tokens: Optional[int] = None,
        total_output_tokens: Optional[int] = None,
        total_cache_read_tokens: Optional[int] = None,
        total_cache_write_tokens: Optional[int] = None,
        total_cost: Optional[float] = None,
        current_context_tokens: Optional[int] = None,
        turn_count: Optional[int] = None,
    ) -> str:
        """Stream a rollout result and return the rollout_id."""
        if not self.session:
            raise RuntimeError(
                "ResultStreamer not properly initialized. Use async context manager."
            )

        payload = {
            "local_task_id": local_task_id,
            "run_number": run_number,
            "success": success,
            "grade_result": grade_result,
            "extracted_score": extracted_score,
            "format": format,
        }

        # Include task_version_id if available
        if task_version_id is not None:
            payload["task_version_id"] = task_version_id

        # Include usage/cost fields if available
        if total_input_tokens is not None:
            payload["total_input_tokens"] = total_input_tokens
        if total_output_tokens is not None:
            payload["total_output_tokens"] = total_output_tokens
        if total_cache_read_tokens is not None:
            payload["total_cache_read_tokens"] = total_cache_read_tokens
        if total_cache_write_tokens is not None:
            payload["total_cache_write_tokens"] = total_cache_write_tokens
        if total_cost is not None:
            payload["total_cost"] = total_cost
        if current_context_tokens is not None:
            payload["current_context_tokens"] = current_context_tokens
        if turn_count is not None:
            payload["turn_count"] = turn_count

        try:
            async with self.session.post(
                f"{self.server_url}/api/evaluations/{evaluation_id}/rollouts",
                json=payload,
            ) as response:
                if response.status == 404:
                    raise RuntimeError(f"Evaluation {evaluation_id} not found")
                elif response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(
                        f"Failed to stream rollout: {response.status} - {error_text}"
                    )

                result = await response.json()
                rollout_id = result["rollout_id"]
                console.print(f"[blue]Streamed rollout: {rollout_id}[/blue]")
                return rollout_id

        except aiohttp.ClientError as e:
            console.print(
                f"[yellow]Warning: Network error streaming rollout: {e}[/yellow]"
            )
            return None

    async def update_rollout_usage(
        self,
        rollout_id: str,
        usage: Dict[str, Any],
    ) -> bool:
        """Stream live usage/cost update for a rollout. Called every turn."""
        if not self.session:
            return False

        payload = {
            "total_input_tokens": usage.get("total_input_tokens"),
            "total_output_tokens": usage.get("total_output_tokens"),
            "total_cache_read_tokens": usage.get("total_cache_read_tokens"),
            "total_cache_write_tokens": usage.get("total_cache_write_tokens"),
            "total_cost": usage.get("total_cost"),
            "current_context_tokens": usage.get("current_context_tokens"),
            "turn_count": usage.get("turn_count"),
        }

        try:
            async with self.session.patch(
                f"{self.server_url}/api/rollouts/{rollout_id}",
                json=payload,
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    console.print(
                        f"[yellow]Warning: Failed to stream usage update: {response.status} - {error_text}[/yellow]"
                    )
                    return False
                return True

        except Exception as e:
            console.print(
                f"[yellow]Warning: Network error streaming usage: {e}[/yellow]"
            )
            return False

    async def stream_messages(
        self, evaluation_id: str, rollout_id: str, messages: List[Dict[str, Any]]
    ) -> bool:
        """Stream conversation messages for a rollout."""
        if not self.session:
            raise RuntimeError(
                "ResultStreamer not properly initialized. Use async context manager."
            )

        if not messages:
            return True

        payload = {"rollout_id": rollout_id, "messages": messages}

        start = time.time()
        try:
            async with self.session.post(
                f"{self.server_url}/api/evaluations/{evaluation_id}/messages",
                json=payload,
            ) as response:
                if response.status == 404:
                    console.print(
                        f"[yellow]Warning: Evaluation {evaluation_id} or rollout {rollout_id} not found[/yellow]"
                    )
                    return False
                elif response.status != 200:
                    error_text = await response.text()
                    console.print(
                        f"[yellow]Warning: Failed to stream messages: {response.status} - {error_text}[/yellow]"
                    )
                    return False

                result = await response.json()
                console.print(f"[dim]Streamed {result['message_count']} messages[/dim]")
                return True

        except Exception:
            end = time.time()
            print(
                f"DEBUG: eval_id {evaluation_id} rollout_id {rollout_id}, time: {end - start}"
            )
            raise

    async def complete_evaluation(
        self, evaluation_id: str, status: str = "completed"
    ) -> bool:
        """Mark evaluation as completed or failed."""
        if not self.session:
            raise RuntimeError(
                "ResultStreamer not properly initialized. Use async context manager."
            )

        payload = {"status": status}

        try:
            async with self.session.post(
                f"{self.server_url}/api/evaluations/{evaluation_id}/complete",
                json=payload,
            ) as response:
                if response.status == 404:
                    console.print(
                        f"[yellow]Warning: Evaluation {evaluation_id} not found[/yellow]"
                    )
                    return False
                elif response.status != 200:
                    error_text = await response.text()
                    console.print(
                        f"[yellow]Warning: Failed to complete evaluation: {response.status} - {error_text}[/yellow]"
                    )
                    return False

                result = await response.json()
                console.print(
                    f"[green]Evaluation completed: {result['status']}[/green]"
                )
                return True

        except aiohttp.ClientError as e:
            console.print(
                f"[yellow]Warning: Network error completing evaluation: {e}[/yellow]"
            )
            return False


def extract_score_from_grade_result(grade_result: Any) -> Optional[float]:
    """Extract numerical score from grade result, matching EvalRunner.extract_score logic."""
    try:
        if isinstance(grade_result, str):
            # Try to parse as JSON
            grade_data = json.loads(grade_result)
        else:
            grade_data = grade_result

        if isinstance(grade_data, dict):
            if "subscores" in grade_data and "weights" in grade_data:
                # Calculate weighted score
                subscores = grade_data["subscores"]
                weights = grade_data["weights"]
                total_score = sum(
                    subscores[key] * weights[key] for key in subscores.keys()
                )
                return total_score
            elif "score" in grade_data:
                return float(grade_data["score"])

        # If it's already a number
        if isinstance(grade_data, (int, float)):
            return float(grade_data)

        return 0.0
    except Exception:
        return 0.0
